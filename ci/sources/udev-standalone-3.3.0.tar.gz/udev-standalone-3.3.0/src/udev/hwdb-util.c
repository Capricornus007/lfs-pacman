/***
  This file is part of udev.

  Copyright 2012 Kay Sievers <kay@vrfy.org>

  udev is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation; either version 2.1 of the License, or
  (at your option) any later version.

  udev is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with systemd; If not, see <http://www.gnu.org/licenses/>.
***/

#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <ctype.h>

#include "util.h"
#include "strbuf.h"
#include "conf-files.h"
#include "fileio.h"
#include "label.h"
#include "mkdir.h"
#include "path-util.h"

#include "udev.h"
#include "hwdb-util.h"
#include "libudev-hwdb-def.h"

/*
 * Generic udev properties, key/value database based on modalias strings.
 * Uses a Patricia/radix trie to index all matches for efficient lookup.
 */

static char *list_conf_file_path (void) {
        /* the directory of the administrator, and the one of the shipped files */
        static const char *main_hwdb_dir = UDEV_CONF_DIR "/hwdb.d";
        static const char *libexec_dir = UDEV_LIBEXEC_DIR "/hwdb.d";
        const char *path_variable = getenv ("UDEV_HWDB_PATH");
        /* UDEV_HWDB_PATH comes last, so that it cannot override
           system settings. */
        /* System settings can be overriden by putting the files in
           /etc. */
        /* path_variable may be NULL, strjoin works either way. */
        return strjoin(main_hwdb_dir, ":", libexec_dir, ":", path_variable, NULL);
}

/* in-memory trie objects */
struct trie {
        struct trie_node *root;
        struct strbuf *strings;

        size_t nodes_count;
        size_t children_count;
        size_t values_count;

        /* If true, hwdb.bin is created in the compatible format (v1) without the information
         * about the origin of the properties (priority, line number, and source filename),
         * which can be read by all versions of libudev. Otherwise, the format with this
         * additional information (v2) is created, as udev-hwdb does. */
        bool compat;
};

struct trie_node {
        /* prefix, common part for all children of this node */
        size_t prefix_off;

        /* sorted array of pointers to children nodes */
        struct trie_child_entry *children;
        uint8_t children_count;

        /* sorted array of key/value pairs */
        struct trie_value_entry *values;
        size_t values_count;
};

/* children array item with char (0-255) index */
struct trie_child_entry {
        uint8_t c;
        struct trie_node *child;
};

/* value array item with key/value pairs */
struct trie_value_entry {
        size_t key_off;
        size_t value_off;
        size_t filename_off;
        uint32_t line_number;
        uint16_t file_priority;
};

static int trie_children_cmp(const void *v1, const void *v2) {
        const struct trie_child_entry *n1 = v1;
        const struct trie_child_entry *n2 = v2;

        return n1->c - n2->c;
}

static int node_add_child(struct trie *trie, struct trie_node *node, struct trie_node *node_child, uint8_t c) {
        struct trie_child_entry *child;

        /* extend array, add new entry, sort for bisection */
        child = realloc(node->children, (node->children_count + 1) * sizeof(struct trie_child_entry));
        if (!child)
                return -ENOMEM;

        node->children = child;
        trie->children_count++;
        node->children[node->children_count].c = c;
        node->children[node->children_count].child = node_child;
        node->children_count++;
        qsort(node->children, node->children_count, sizeof(struct trie_child_entry), trie_children_cmp);
        trie->nodes_count++;

        return 0;
}

static struct trie_node *node_lookup(const struct trie_node *node, uint8_t c) {
        struct trie_child_entry *child;
        struct trie_child_entry search;

        search.c = c;
        child = bsearch_safe(&search,
                             node->children, node->children_count, sizeof(struct trie_child_entry),
                             trie_children_cmp);
        if (child)
                return child->child;
        return NULL;
}

static void trie_node_cleanup(struct trie_node *node) {
        size_t i;

        for (i = 0; i < node->children_count; i++)
                trie_node_cleanup(node->children[i].child);
        free(node->children);
        free(node->values);
        free(node);
}


static __thread void* trie_values_cmp_param;
static int trie_values_cmp(const void *v1, const void *v2) {
        const struct trie_value_entry *val1 = v1;
        const struct trie_value_entry *val2 = v2;
        struct trie *trie = trie_values_cmp_param;

        return strcmp(trie->strings->buf + val1->key_off,
                      trie->strings->buf + val2->key_off);
}
static int trie_values_cmp_r(const void *v1, const void *v2, void* arg) {
	trie_values_cmp_param = arg;
	return trie_values_cmp(v1, v2);
}

static int trie_node_add_value(struct trie *trie, struct trie_node *node,
                               const char *key, const char *value,
                               const char *filename, uint16_t file_priority, uint32_t line_number) {
        ssize_t k, v, fn;
        struct trie_value_entry *val;

        k = strbuf_add_string(trie->strings, key, strlen(key));
        if (k < 0)
                return k;
        v = strbuf_add_string(trie->strings, value, strlen(value));
        if (v < 0)
                return v;
        fn = 0;
        if (!trie->compat) {
                fn = strbuf_add_string(trie->strings, filename, strlen(filename));
                if (fn < 0)
                        return fn;
        }

        if (node->values_count) {
                struct trie_value_entry search = {
                        .key_off = k,
                        .value_off = v,
                };

                val = xbsearch_r(&search, node->values, node->values_count, sizeof(struct trie_value_entry), trie_values_cmp_r, trie);
                if (val) {
                        /* At this point we have 2 identical properties on the same match-string.
                         * Since we process files in order, we just replace the previous value.
                         */
                        val->value_off = v;
                        val->filename_off = fn;
                        val->file_priority = file_priority;
                        val->line_number = line_number;
                        return 0;
                }
        }

        /* extend array, add new entry, sort for bisection */
        val = realloc(node->values, (node->values_count + 1) * sizeof(struct trie_value_entry));
        if (!val)
                return -ENOMEM;
        trie->values_count++;
        node->values = val;
        node->values[node->values_count].key_off = k;
        node->values[node->values_count].value_off = v;
        node->values[node->values_count].filename_off = fn;
        node->values[node->values_count].file_priority = file_priority;
        node->values[node->values_count].line_number = line_number;
        node->values_count++;
	trie_values_cmp_param = trie;
        qsort(node->values, node->values_count, sizeof(struct trie_value_entry), trie_values_cmp);
        return 0;
}

static int trie_insert(struct trie *trie, struct trie_node *node, const char *search,
                       const char *key, const char *value,
                       const char *filename, uint16_t file_priority, uint32_t line_number) {
        size_t i = 0;
        int err = 0;

        for (;;) {
                size_t p;
                char c;
                struct trie_node *child;

                for (p = 0; (c = trie->strings->buf[node->prefix_off + p]); p++) {
                        _cleanup_free_ char *s = NULL;
                        ssize_t off;
                        _cleanup_free_ struct trie_node *new_child = NULL;

                        if (c == search[i + p])
                                continue;

                        /* split node */
                        new_child = new0(struct trie_node, 1);
                        if (!new_child)
                                return -ENOMEM;

                        /* move values from parent to child */
                        new_child->prefix_off = node->prefix_off + p+1;
                        new_child->children = node->children;
                        new_child->children_count = node->children_count;
                        new_child->values = node->values;
                        new_child->values_count = node->values_count;

                        /* update parent; use strdup() because the source gets realloc()d */
                        s = strndup(trie->strings->buf + node->prefix_off, p);
                        if (!s)
                                return -ENOMEM;

                        off = strbuf_add_string(trie->strings, s, p);
                        if (off < 0)
                                return off;

                        node->prefix_off = off;
                        node->children = NULL;
                        node->children_count = 0;
                        node->values = NULL;
                        node->values_count = 0;
                        err = node_add_child(trie, node, new_child, c);
                        if (err) {
                                /* undo the split, to not lose the moved children and values */
                                *node = *new_child;
                                node->prefix_off -= p + 1;
                                return err;
                        }

                        new_child = NULL; /* avoid cleanup */
                        break;
                }
                i += p;

                c = search[i];
                if (c == '\0')
                        return trie_node_add_value(trie, node, key, value, filename, file_priority, line_number);

                child = node_lookup(node, c);
                if (!child) {
                        ssize_t off;

                        /* new child */
                        child = new0(struct trie_node, 1);
                        if (!child)
                                return -ENOMEM;

                        off = strbuf_add_string(trie->strings, search + i+1, strlen(search + i+1));
                        if (off < 0) {
                                free(child);
                                return off;
                        }

                        child->prefix_off = off;
                        err = node_add_child(trie, node, child, c);
                        if (err) {
                                free(child);
                                return err;
                        }

                        return trie_node_add_value(trie, child, key, value, filename, file_priority, line_number);
                }

                node = child;
                i++;
        }
}

struct trie_f {
        FILE *f;
        struct trie *trie;
        uint64_t strings_off;

        uint64_t nodes_count;
        uint64_t children_count;
        uint64_t values_count;
};

/* calculate the storage space for the nodes, children arrays, value arrays */
static void trie_store_nodes_size(struct trie_f *trie, struct trie_node *node) {
        uint64_t i;

        for (i = 0; i < node->children_count; i++)
                trie_store_nodes_size(trie, node->children[i].child);

        trie->strings_off += sizeof(struct trie_node_f);
        for (i = 0; i < node->children_count; i++)
                trie->strings_off += sizeof(struct trie_child_entry_f);
        for (i = 0; i < node->values_count; i++)
                trie->strings_off += trie->trie->compat ? sizeof(struct trie_value_entry_f) : sizeof(struct trie_value_entry2_f);
}

static int64_t trie_store_nodes(struct trie_f *trie, struct trie_node *node) {
        uint64_t i;
        struct trie_node_f n = {
                .prefix_off = htole64(trie->strings_off + node->prefix_off),
                .children_count = node->children_count,
                .values_count = htole64(node->values_count),
        };
        struct trie_child_entry_f *children = NULL;
        int64_t node_off;

        if (node->children_count) {
                children = new0(struct trie_child_entry_f, node->children_count);
                if (!children)
                        return -ENOMEM;
        }

        /* post-order recursion */
        for (i = 0; i < node->children_count; i++) {
                int64_t child_off;

                child_off = trie_store_nodes(trie, node->children[i].child);
                if (child_off < 0) {
                        free(children);
                        return child_off;
                }
                children[i].c = node->children[i].c;
                children[i].child_off = htole64(child_off);
        }

        /* write node */
        node_off = ftello(trie->f);
        fwrite(&n, sizeof(struct trie_node_f), 1, trie->f);
        trie->nodes_count++;

        /* append children array */
        if (node->children_count) {
                fwrite(children, sizeof(struct trie_child_entry_f), node->children_count, trie->f);
                trie->children_count += node->children_count;
                free(children);
        }

        /* append values array */
        for (i = 0; i < node->values_count; i++) {
                struct trie_value_entry2_f v = {
                        .key_off = htole64(trie->strings_off + node->values[i].key_off),
                        .value_off = htole64(trie->strings_off + node->values[i].value_off),
                        .filename_off = htole64(trie->strings_off + node->values[i].filename_off),
                        .line_number = htole32(node->values[i].line_number),
                        .file_priority = htole16(node->values[i].file_priority),
                };

                fwrite(&v, trie->trie->compat ? sizeof(struct trie_value_entry_f) : sizeof(struct trie_value_entry2_f), 1, trie->f);
                trie->values_count++;
        }

        return node_off;
}

static int trie_store(struct trie *trie, const char *filename) {
        _cleanup_free_ char *lesc1 = NULL;
        struct trie_f t = {
                .trie = trie,
        };
        _cleanup_free_ char *filename_tmp = NULL;
        int64_t pos;
        int64_t root_off;
        int64_t size;
        struct trie_header_f h = {
                .signature = HWDB_SIG,
                .tool_version = htole64(atoi(UDEV_VERSION)),
                .header_size = htole64(sizeof(struct trie_header_f)),
                .node_size = htole64(sizeof(struct trie_node_f)),
                .child_entry_size = htole64(sizeof(struct trie_child_entry_f)),
                .value_entry_size = htole64(trie->compat ? sizeof(struct trie_value_entry_f) : sizeof(struct trie_value_entry2_f)),
        };
        int err;

        /* calculate size of header, nodes, children entries, value entries */
        t.strings_off = sizeof(struct trie_header_f);
        trie_store_nodes_size(&t, trie->root);

        err = fopen_temporary(filename , &t.f, &filename_tmp);
        if (err < 0)
                return err;
        fchmod(fileno(t.f), 0444);

        /* write nodes */
        err = fseeko(t.f, sizeof(struct trie_header_f), SEEK_SET);
        if (err < 0) {
                fclose(t.f);
                unlink_noerrno(filename_tmp);
                return -errno;
        }
        root_off = trie_store_nodes(&t, trie->root);
        if (root_off < 0) {
                /* systemd writes the database anyway */
                fclose(t.f);
                unlink_noerrno(filename_tmp);
                return root_off;
        }
        h.nodes_root_off = htole64(root_off);
        pos = ftello(t.f);
        h.nodes_len = htole64(pos - sizeof(struct trie_header_f));

        /* write string buffer */
        fwrite(trie->strings->buf, trie->strings->len, 1, t.f);
        h.strings_len = htole64(trie->strings->len);

        /* write header */
        size = ftello(t.f);
        h.file_size = htole64(size);
        err = fseeko(t.f, 0, SEEK_SET);
        if (err < 0) {
                fclose(t.f);
                unlink_noerrno(filename_tmp);
                return -errno;
        }
        fwrite(&h, sizeof(struct trie_header_f), 1, t.f);
        err = ferror(t.f);
        if (err)
                err = -errno;
        fclose(t.f);
        if (err < 0 || rename(filename_tmp, filename) < 0) {
                unlink_noerrno(filename_tmp);
                return err < 0 ? err : -errno;
        }

        log_debug("=== trie on-disk ===");
        log_debug("filename:         %s", utf8_escape_for_log(filename, &lesc1));
        log_debug("size:             %8"PRIi64" bytes", size);
        log_debug("header:           %8zu bytes", sizeof(struct trie_header_f));
        log_debug("nodes:            %8"PRIu64" bytes (%8"PRIu64")",
                  t.nodes_count * sizeof(struct trie_node_f), t.nodes_count);
        log_debug("child pointers:   %8"PRIu64" bytes (%8"PRIu64")",
                  t.children_count * sizeof(struct trie_child_entry_f), t.children_count);
        log_debug("value pointers:   %8"PRIu64" bytes (%8"PRIu64")",
                  t.values_count * (trie->compat ? sizeof(struct trie_value_entry_f) : sizeof(struct trie_value_entry2_f)), t.values_count);
        log_debug("string store:     %8zu bytes", trie->strings->len);
        log_debug("strings start:    %8"PRIu64, t.strings_off);

        return 0;
}

/* Like systemd's log_syntax() for a line of a file: "FILE:LINE: message". The name of the file is escaped like the
 * values in the messages of udev. */
#define log_syntax(level, filename, line_number, fmt, ...)                                              \
        ({                                                                                              \
                _cleanup_free_ char *_fn = NULL;                                                        \
                log_full(level, "%s:%u: " fmt, utf8_escape_for_log(filename, &_fn), (unsigned) (line_number), \
                         ##__VA_ARGS__);                                                                \
        })

/* Returns 0, 1 if the line has a syntax error, which is logged and the line ignored, or a negative errno,
 * e.g. -ENOMEM, if the data cannot be inserted. */
static int insert_data(struct trie *trie, struct udev_list *match_list,
                       char *line, const char *filename, uint16_t file_priority, uint32_t line_number) {
        _cleanup_free_ char *lesc1 = NULL, *lesc2 = NULL;
        char *value;
        struct udev_list_entry *entry;
        int r;

        assert(line[0] == ' ');

        value = strchr(line, '=');
        if (!value) {
                log_syntax(LOG_WARNING, filename, line_number,
                           "Key-value pair expected but got \"%s\", ignoring.", utf8_escape_for_log(line, &lesc1));
                return 1;
        }

        value[0] = '\0';
        value++;

        /* Replace multiple leading spaces by a single space */
        while (isblank((unsigned char) line[0]) && isblank((unsigned char) line[1]))
                line++;

        if (isempty(line + 1)) {
                log_syntax(LOG_WARNING, filename, line_number,
                           "Empty key in \"%s=%s\", ignoring.",
                           utf8_escape_for_log(line, &lesc1), utf8_escape_for_log(value, &lesc2));
                return 1;
        }

        udev_list_entry_foreach(entry, udev_list_get_entry(match_list)) {
                r = trie_insert(trie, trie->root, udev_list_entry_get_name(entry), line, value,
                                filename, file_priority, line_number);
                if (r < 0)
                        return log_error_errno(r, "%s:%u: Failed to insert '%s': %m",
                                               utf8_escape_for_log(filename, &lesc1), line_number,
                                               utf8_escape_for_log(udev_list_entry_get_name(entry), &lesc2));
        }

        return 0;
}

/* Returns 0, 1 if there were syntax errors, which are logged and the lines ignored, or a negative errno if
 * the file cannot be read or the data cannot be inserted. In the latter case, which insert_data() logs
 * with the file and line, *ret_logged is set to true. */
static int import_file(struct udev *udev, struct trie *trie, const char *filename, const char *path_in_root,
                       uint16_t file_priority, bool *ret_logged) {
        _cleanup_free_ char *lesc1 = NULL;
        enum {
                HW_MATCH,
                HW_DATA,
                HW_NONE,
        } state = HW_NONE;
        _cleanup_fclose_ FILE *f = NULL;
        struct udev_list match_list;
        uint32_t line_number = 0;
        bool syntax_errors = false;
        int r, err;

        assert(ret_logged);

        *ret_logged = false;
        udev_list_init(udev, &match_list, false);

        f = fopen(filename, "re");
        if (!f)
                return -errno;

        for (;;) {
                _cleanup_free_ char *line = NULL;
                size_t len;
                char *pos;

                /* Like systemd, a line longer than LONG_LINE_MAX is an error, instead of being split. */
                r = read_line(f, LONG_LINE_MAX, &line);
                if (r < 0)
                        goto finish;
                if (r == 0)
                        break;

                ++line_number;

                /* comment line */
                if (line[0] == '#')
                        continue;

                /* strip trailing comment */
                pos = strchr(line, '#');
                if (pos)
                        pos[0] = '\0';

                /* strip trailing whitespace */
                len = strlen(line);
                while (len > 0 && isspace((unsigned char) line[len-1]))
                        len--;
                line[len] = '\0';

                switch (state) {
                case HW_NONE:
                        if (len == 0)
                                break;

                        if (line[0] == ' ') {
                                log_syntax(LOG_WARNING, path_in_root, line_number,
                                           "Match expected but got indented property \"%s\", ignoring line.",
                                           utf8_escape_for_log(line, &lesc1));
                                syntax_errors = true;
                                break;
                        }

                        /* start of record, first match */
                        state = HW_MATCH;
                        if (!udev_list_entry_add(&match_list, line, NULL)) {
                                r = -ENOMEM;
                                goto finish;
                        }
                        break;

                case HW_MATCH:
                        if (len == 0) {
                                log_syntax(LOG_WARNING, path_in_root, line_number,
                                           "Property expected, ignoring record with no properties.");
                                syntax_errors = true;
                                state = HW_NONE;
                                udev_list_cleanup(&match_list);
                                break;
                        }

                        if (line[0] != ' ') {
                                /* another match */
                                if (!udev_list_entry_add(&match_list, line, NULL)) {
                                        r = -ENOMEM;
                                        goto finish;
                                }
                                break;
                        }

                        /* first data */
                        state = HW_DATA;
                        err = insert_data(trie, &match_list, line, path_in_root, file_priority, line_number);
                        if (err < 0) {
                                *ret_logged = true;
                                r = err;
                                goto finish;
                        }
                        if (err > 0)
                                syntax_errors = true;
                        break;

                case HW_DATA:
                        if (len == 0) {
                                /* end of record */
                                state = HW_NONE;
                                udev_list_cleanup(&match_list);
                                break;
                        }

                        if (line[0] != ' ') {
                                log_syntax(LOG_WARNING, path_in_root, line_number,
                                           "Property or empty line expected, got \"%s\", ignoring record.",
                                           utf8_escape_for_log(line, &lesc1));
                                syntax_errors = true;
                                state = HW_NONE;
                                udev_list_cleanup(&match_list);
                                break;
                        }

                        err = insert_data(trie, &match_list, line, path_in_root, file_priority, line_number);
                        if (err < 0) {
                                *ret_logged = true;
                                r = err;
                                goto finish;
                        }
                        if (err > 0)
                                syntax_errors = true;
                        break;
                };
        }

        if (state == HW_MATCH) {
                log_syntax(LOG_WARNING, path_in_root, line_number,
                           "Property expected, ignoring record with no properties.");
                syntax_errors = true;
        }

        r = syntax_errors;

finish:
        udev_list_cleanup(&match_list);
        return r;
}

int hwdb_update(struct udev *udev, const char *root, const char *hwdb_bin, bool strict) {
        _cleanup_free_ char *lesc1 = NULL, *lesc2 = NULL;
        _cleanup_free_ char *conf_file_path = NULL, *full_hwdb_bin = NULL;
        _cleanup_strv_free_ char **dirs = NULL;
        struct trie *trie = NULL;
        ConfFile **files = NULL;
        size_t n_files = 0, i;
        uint16_t file_priority = 1;
        int err, format, ret = 0;

        assert(hwdb_bin);

        if (!root)
                root = "";

        if (strlen(root)) {
                /* --root has been specified, prepend it to
                   the hwdb.bin destination file, like the reference implementation's path_join(). */
                full_hwdb_bin = path_join(root, hwdb_bin);
                /* Do nothing if no --root, so that hwdb_bin
                   may still be relative. */
                if (full_hwdb_bin == NULL)
                        return log_oom();
                hwdb_bin = full_hwdb_bin;
        }

        trie = new0(struct trie, 1);
        if (!trie) {
                err = log_oom();
                goto out;
        }

        /* By default, create hwdb.bin in the compatible format (1), which can be read by
         * all versions of libudev, like upstream's 'udevadm hwdb' does. The format is
         * configured with hwdb_format= in udev.conf, below the root directory if specified. */
        if (strlen(root))
                format = udev_read_hwdb_format(root);
        else
                format = udev_get_hwdb_format(udev);
        if (format == -ENOMEM) {
                err = log_oom();
                goto out;
        }
        if (format < 0) {
                log_warning("Invalid hwdb_format= in udev.conf, using 1.");
                format = 1;
        }
        log_debug("creating hwdb.bin in format %i", format);
        trie->compat = format == 1;

        /* string store */
        trie->strings = strbuf_new();
        if (!trie->strings) {
                err = log_oom();
                goto out;
        }

        /* index */
        trie->root = new0(struct trie_node, 1);
        if (!trie->root) {
                err = log_oom();
                goto out;
        }
        trie->nodes_count++;

        conf_file_path = list_conf_file_path ();
        if (conf_file_path == NULL) {
                err = log_oom();
                goto out;
        }
        err = strv_split_and_extend(&dirs, conf_file_path, ":", false);
        if (err < 0) {
                err = log_oom();
                goto out;
        }

        /* Like systemd, masks, i.e. symlinks to /dev/null and empty files, and files that are not regular
         * files are not listed, so that they do not count as hwdb files. The files are resolved below
         * root. Unlike the reference implementation, which ignores a directory that cannot be read, and then writes a database
         * without its files, or removes hwdb.bin, if there are no other files, keep the old hwdb.bin. */
        err = conf_files_list_strv_full(".hwdb", root,
                                        CONF_FILES_REGULAR | CONF_FILES_FILTER_MASKED | CONF_FILES_WARN |
                                        CONF_FILES_FAIL_ON_UNREADABLE_DIR,
                                        (const char * const *) dirs, &files, &n_files);
        if (err < 0) {
                log_error_errno(err, "Failed to enumerate hwdb files, not updating %s: %m",
                                utf8_escape_for_log(hwdb_bin, &lesc1));
                goto out;
        }

        if (n_files == 0) {
                if (unlink(hwdb_bin) < 0) {
                        if (errno != ENOENT) {
                                err = log_error_errno(errno, "Failed to remove compiled hwdb database %s: %m",
                                                      utf8_escape_for_log(hwdb_bin, &lesc1));
                                goto out;
                        }

                        log_info("No hwdb files found, skipping.");
                } else
                        log_info("No hwdb files found, compiled hwdb database %s removed.",
                                 utf8_escape_for_log(hwdb_bin, &lesc1));

                err = 0;
                goto out;
        }

        for (i = 0; i < n_files; i++) {
                const ConfFile *c = files[i];
                const char *path_in_root = c->original_path;
                bool logged;

                /* Like systemd, the database stores the path as found in the directory, without the
                 * root, to not leak build paths and keep the database reproducible, and the file is read
                 * with its symlinks resolved below the root. */
                if (!isempty(root)) {
                        const char *p = path_startswith(c->original_path, root);

                        if (p && p > c->original_path && p[-1] == '/')
                                path_in_root = p - 1;
                }

                log_debug("Reading file \"%s\" -> \"%s\"",
                          utf8_escape_for_log(c->original_path, &lesc1), utf8_escape_for_log(c->resolved_path, &lesc2));
                err = import_file(udev, trie, c->resolved_path, path_in_root, file_priority++, &logged);
                if (err < 0) {
                        /* Unlike the reference implementation, which writes a database without the data that could not be
                         * read, and returns the error only with --strict, keep the old hwdb.bin. A failure
                         * to insert the data is logged with the file and line already. */
                        if (!logged)
                                log_error_errno(err, "Failed to read hwdb file '%s', not updating %s: %m",
                                                utf8_escape_for_log(c->original_path, &lesc1),
                                                utf8_escape_for_log(hwdb_bin, &lesc2));
                        goto out;
                }
                if (err > 0 && ret == 0)
                        ret = -EINVAL;
        }

        strbuf_complete(trie->strings);

        log_debug("=== trie in-memory ===");
        log_debug("nodes:            %8zu bytes (%8zu)",
                  trie->nodes_count * sizeof(struct trie_node), trie->nodes_count);
        log_debug("children arrays:  %8zu bytes (%8zu)",
                  trie->children_count * sizeof(struct trie_child_entry), trie->children_count);
        log_debug("values arrays:    %8zu bytes (%8zu)",
                  trie->values_count * sizeof(struct trie_value_entry), trie->values_count);
        log_debug("strings:          %8zu bytes",
                  trie->strings->len);
        log_debug("strings incoming: %8zu bytes (%8zu)",
                  trie->strings->in_len, trie->strings->in_count);
        log_debug("strings dedup'ed: %8zu bytes (%8zu)",
                  trie->strings->dedup_len, trie->strings->dedup_count);

        mkdir_parents_label(hwdb_bin, 0755);
        err = trie_store(trie, hwdb_bin);
        if (err < 0) {
                log_error_errno(err, "Failure writing database %s: %m", utf8_escape_for_log(hwdb_bin, &lesc1));
                goto out;
        }

        err = label_fix(hwdb_bin, false, false);
        if (err < 0)
                goto out;

        err = strict ? ret : 0;
out:
        conf_file_free_array(files, n_files);
        if (trie) {
                if (trie->root)
                        trie_node_cleanup(trie->root);
                strbuf_cleanup(trie->strings);
                free(trie);
        }
        return err;
}

int hwdb_query(struct udev *udev, const char *modalias, const char *root) {
        struct udev_hwdb *hwdb = NULL;
        struct udev_list_entry *entry;

        assert(modalias);

        errno = 0;
        if (!isempty(root)) {
                /* the locations of hwdb.bin that libudev reads, below root */
                static const char *const bin_paths[] = {
                        UDEV_HWDB_BIN,
                        UDEV_LIBEXEC_DIR "/hwdb.bin",
                };
                unsigned i;

                for (i = 0; i < ELEMENTSOF(bin_paths) && !hwdb; i++) {
                        _cleanup_free_ char *hwdb_bin = NULL;

                        hwdb_bin = path_join(root, bin_paths[i]);
                        if (!hwdb_bin)
                                return log_oom();

                        hwdb = udev_hwdb_new_from_path(udev, hwdb_bin);
                }
        } else
                hwdb = udev_hwdb_new(udev);
        if (!hwdb)
                return log_error_errno(errno > 0 ? errno : ENOENT, "Failed to open the hardware database (hwdb.bin): %m");

        udev_list_entry_foreach(entry, udev_hwdb_get_properties_list_entry(hwdb, modalias, 0))
                printf("%s=%s\n", udev_list_entry_get_name(entry), udev_list_entry_get_value(entry));

        udev_hwdb_unref(hwdb);
        return 0;
}
