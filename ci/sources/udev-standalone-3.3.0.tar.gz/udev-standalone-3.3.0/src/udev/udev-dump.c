/*
 * Copyright (C) 2003-2004 Greg Kroah-Hartman <greg@kroah.com>
 * Copyright (C) 2004-2008 Kay Sievers <kay@vrfy.org>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <grp.h>
#include <pwd.h>

#include "udev.h"
#include "strv.h"
#include "terminal-util.h"

static int str_compare(const void *a, const void *b) {
        return strcmp(*(char * const *) a, *(char * const *) b);
}

/* Returns the properties as "KEY=VALUE" strings, like the reference implementation's device_get_properties_strv(): the
 * database version, which udevd passes with the properties, and all properties, sorted as strings,
 * as systemd's dump does. Like there, the properties are walked only once, so that the list always fits
 * them, also when getting them reads the database, which may add properties. */
static char **dump_properties_strv(struct udev_device *dev) {
        _cleanup_strv_free_ char **l = NULL;
        struct udev_list_entry *entry;
        size_t allocated = 0, n = 0;
        char *s;

        if (!GREEDY_REALLOC(l, allocated, 2))
                return NULL;
        l[0] = NULL;
        if (asprintf(&s, "UDEV_DATABASE_VERSION=%u", LATEST_UDEV_DATABASE_VERSION) < 0)
                return NULL;
        l[n++] = s;
        l[n] = NULL;

        udev_list_entry_foreach(entry, udev_device_get_properties_list_entry(dev)) {
                s = strjoin(udev_list_entry_get_name(entry), "=", udev_list_entry_get_value(entry), NULL);
                if (!s)
                        return NULL;
                if (!GREEDY_REALLOC(l, allocated, n + 2)) {
                        free(s);
                        return NULL;
                }
                l[n++] = s;
                l[n] = NULL;
        }

        qsort(l, n, sizeof(char *), str_compare);
        return TAKE_PTR(l);
}

/* Returns the owner, group and mode of the device node, and whether they apply. They do not for remove
 * events, see udev_event_execute_rules(). When not set by the rules processed so far,
 * udev_event_execute_rules() will use the values of the device. */
static bool event_get_node_perms(struct udev_event *event, uid_t *ret_uid, gid_t *ret_gid, mode_t *ret_mode) {
        struct udev_device *dev = event->dev;
        uid_t uid;
        gid_t gid;
        mode_t mode;

        if (major(udev_device_get_devnum(dev)) == 0 || streq_ptr(udev_device_get_action(dev), "remove"))
                return false;

        uid = event->owner_set ? event->uid : udev_device_get_devnode_uid(dev);
        gid = event->group_set ? event->gid : udev_device_get_devnode_gid(dev);
        if (event->mode_set)
                mode = event->mode;
        else if (udev_device_get_devnode_mode(dev) > 0)
                mode = udev_device_get_devnode_mode(dev);
        else
                mode = gid > 0 ? 0660 : 0600;

        *ret_uid = uid;
        *ret_gid = gid;
        *ret_mode = mode;
        return true;
}

static int dump_event_json(struct udev_event *event, JsonFormatFlags flags, FILE *f) {
        struct udev_device *dev = event->dev;
        struct udev_list_entry *entry;
        _cleanup_strv_free_ char **properties = NULL;
        char **p;
        const char *subsys, *str;
        unsigned sysnum;
        JsonWriter w;
        uid_t uid;
        gid_t gid;
        mode_t mode;
        int ifindex;

        json_writer_init(&w, f, flags);
        json_writer_object_begin(&w);

        str = udev_device_get_devpath(dev);
        if (str)
                json_writer_field_string(&w, "path", str);

        str = udev_device_get_sysname(dev);
        if (str)
                json_writer_field_string(&w, "name", str);

        str = udev_device_get_sysnum(dev);
        if (str && safe_atou(str, &sysnum) >= 0)
                json_writer_field_unsigned(&w, "number", sysnum);

        str = udev_device_get_id_filename(dev);
        if (str)
                json_writer_field_string(&w, "id", str);

        subsys = udev_device_get_subsystem(dev);
        if (subsys)
                json_writer_field_string(&w, "subsystem", subsys);

        str = udev_device_get_devtype(dev);
        if (str)
                json_writer_field_string(&w, "type", str);

        str = udev_device_get_driver(dev);
        if (str)
                json_writer_field_string(&w, "driver", str);

        str = udev_device_get_devnode(dev);
        if (str) {
                dev_t devnum = udev_device_get_devnum(dev);

                json_writer_key(&w, "node");
                json_writer_object_begin(&w);

                json_writer_field_string(&w, "path", str);
                json_writer_field_string(&w, "type", streq_ptr(subsys, "block") ? "block" : "char");

                json_writer_key(&w, "rdev");
                if (major(devnum) > 0) {
                        json_writer_object_begin(&w);
                        json_writer_field_unsigned(&w, "major", major(devnum));
                        json_writer_field_unsigned(&w, "minor", minor(devnum));
                        json_writer_object_end(&w);
                } else
                        json_writer_null(&w);

                if (event_get_node_perms(event, &uid, &gid, &mode)) {
                        struct passwd *pw = getpwuid(uid);
                        struct group *gr = getgrgid(gid);
                        char buf[DECIMAL_STR_MAX(unsigned)];

                        json_writer_key(&w, "owner");
                        json_writer_object_begin(&w);
                        json_writer_field_unsigned(&w, "uid", uid);
                        if (!pw)
                                snprintf(buf, sizeof(buf), UID_FMT, uid);
                        json_writer_field_string(&w, "userName", pw ? pw->pw_name : buf);
                        json_writer_field_unsigned(&w, "gid", gid);
                        if (!gr)
                                snprintf(buf, sizeof(buf), GID_FMT, gid);
                        json_writer_field_string(&w, "groupName", gr ? gr->gr_name : buf);
                        json_writer_object_end(&w);

                        snprintf(buf, sizeof(buf), "%04o", mode & ~S_IFMT);
                        json_writer_field_string(&w, "mode", buf);
                }

                if (udev_device_get_devlinks_list_entry(dev)) {
                        json_writer_field_integer(&w, "symlinkPriority", udev_device_get_devlink_priority(dev));
                        json_writer_key(&w, "symlinks");
                        json_writer_array_begin(&w);
                        udev_list_entry_foreach(entry, udev_device_get_devlinks_list_entry(dev))
                                json_writer_string(&w, udev_list_entry_get_name(entry));
                        json_writer_array_end(&w);
                }

                if (udev_list_get_entry(&event->seclabel_list)) {
                        json_writer_key(&w, "securityLabels");
                        json_writer_array_begin(&w);
                        udev_list_entry_foreach(entry, udev_list_get_entry(&event->seclabel_list)) {
                                json_writer_object_begin(&w);
                                json_writer_field_string(&w, "name", udev_list_entry_get_name(entry));
                                json_writer_field_string(&w, "label", udev_list_entry_get_value(entry));
                                json_writer_object_end(&w);
                        }
                        json_writer_array_end(&w);
                }

                json_writer_field_boolean(&w, "inotifyWatch", event->inotify_watch);

                json_writer_object_end(&w);
        }

        ifindex = udev_device_get_ifindex(dev);
        if (ifindex > 0) {
                json_writer_key(&w, "networkInterface");
                json_writer_object_begin(&w);
                json_writer_field_integer(&w, "index", ifindex);
                if (!isempty(event->name))
                        json_writer_field_string(&w, "name", event->name);
                /* like the reference implementation, all requested names, sorted, also the name of the interface */
                if (!strv_isempty(event->altnames)) {
                        json_writer_key(&w, "alternativeNames");
                        json_writer_array_begin(&w);
                        STRV_FOREACH(p, strv_sort(event->altnames))
                                json_writer_string(&w, *p);
                        json_writer_array_end(&w);
                }
                json_writer_object_end(&w);
        }

        if (udev_list_get_entry(&event->written_sysattr_list)) {
                json_writer_key(&w, "sysfsAttributes");
                json_writer_array_begin(&w);
                udev_list_entry_foreach(entry, udev_list_get_entry(&event->written_sysattr_list)) {
                        json_writer_object_begin(&w);
                        json_writer_field_string(&w, "path", udev_list_entry_get_name(entry));
                        json_writer_field_string(&w, "value", udev_list_entry_get_value(entry));
                        json_writer_object_end(&w);
                }
                json_writer_array_end(&w);
        }

        if (udev_list_get_entry(&event->written_sysctl_list)) {
                json_writer_key(&w, "sysctl");
                json_writer_array_begin(&w);
                udev_list_entry_foreach(entry, udev_list_get_entry(&event->written_sysctl_list)) {
                        json_writer_object_begin(&w);
                        json_writer_field_string(&w, "path", udev_list_entry_get_name(entry));
                        json_writer_field_string(&w, "value", udev_list_entry_get_value(entry));
                        json_writer_object_end(&w);
                }
                json_writer_array_end(&w);
        }

        if (udev_device_get_tags_list_entry(dev)) {
                json_writer_key(&w, "tags");
                json_writer_array_begin(&w);
                udev_list_entry_foreach(entry, udev_device_get_tags_list_entry(dev))
                        json_writer_string(&w, udev_list_entry_get_name(entry));
                json_writer_array_end(&w);
        }

        if (udev_device_get_current_tags_list_entry(dev)) {
                json_writer_key(&w, "currentTags");
                json_writer_array_begin(&w);
                udev_list_entry_foreach(entry, udev_device_get_current_tags_list_entry(dev))
                        json_writer_string(&w, udev_list_entry_get_name(entry));
                json_writer_array_end(&w);
        }

        properties = dump_properties_strv(dev);
        if (!properties)
                return log_oom();
        json_writer_key(&w, "properties");
        json_writer_array_begin(&w);
        STRV_FOREACH(p, properties)
                json_writer_string(&w, *p);
        json_writer_array_end(&w);

        if (udev_list_get_entry(&event->run_list)) {
                json_writer_key(&w, "queuedCommands");
                json_writer_array_begin(&w);
                udev_list_entry_foreach(entry, udev_list_get_entry(&event->run_list)) {
                        json_writer_object_begin(&w);
                        json_writer_field_string(&w, "type",
                                                 udev_list_entry_get_num(entry) < UDEV_BUILTIN_MAX ? "builtin" : "program");
                        json_writer_field_string(&w, "command", udev_list_entry_get_name(entry));
                        json_writer_object_end(&w);
                }
                json_writer_array_end(&w);
        }

        json_writer_object_end(&w);
        return json_writer_finish(&w);
}

/* Unlike the reference implementation, the values of the dump are escaped like the values in the messages, see
 * utf8_escape_non_printable(): control characters and invalid UTF-8 are shown as \xNN, so that each value
 * stays on its line, also in the messages of OPTIONS="dump". Without memory, a value is shown as it is. */

static char *dump_escape(const char *s) {
        return s ? utf8_escape_non_printable(s) : NULL;
}

/* "<label>:\n  <value>\n" */
static void dump_field(FILE *f, const char *label, const char *value) {
        _cleanup_free_ char *escaped = dump_escape(value);

        fprintf(f, "%s%s:%s\n  %s\n", ansi_highlight(), label, ansi_normal(), escaped ?: strna(value));
}

/* "  <value>\n" */
static void dump_value(FILE *f, const char *value) {
        _cleanup_free_ char *escaped = dump_escape(value);

        fprintf(f, "  %s\n", escaped ?: strna(value));
}

/* "  <name> : <value>\n" */
static void dump_pair(FILE *f, const char *name, const char *value) {
        _cleanup_free_ char *escaped_name = dump_escape(name), *escaped = dump_escape(value);

        fprintf(f, "  %s : %s\n", escaped_name ?: strna(name), escaped ?: strna(value));
}

int dump_event(struct udev_event *event, JsonFormatFlags flags, FILE *f) {
        struct udev_device *dev = event->dev;
        struct udev_list_entry *entry;
        _cleanup_strv_free_ char **properties = NULL;
        char **p;
        const char *subsys, *str;
        int ifindex;

        if (!f)
                f = stdout;

        if (json_format_enabled(flags))
                return dump_event_json(event, flags, f);

        str = udev_device_get_devpath(dev);
        if (str)
                dump_field(f, "Device path", str);

        str = udev_device_get_sysname(dev);
        if (str)
                dump_field(f, "Device name", str);

        str = udev_device_get_sysnum(dev);
        if (str)
                dump_field(f, "Device number", str);

        str = udev_device_get_id_filename(dev);
        if (str)
                dump_field(f, "Device ID", str);

        subsys = udev_device_get_subsystem(dev);
        if (subsys)
                dump_field(f, "Subsystem", subsys);

        str = udev_device_get_devtype(dev);
        if (str)
                dump_field(f, "Device type", str);

        str = udev_device_get_driver(dev);
        if (str)
                dump_field(f, "Device driver", str);

        str = udev_device_get_devnode(dev);
        if (str) {
                dev_t devnum = udev_device_get_devnum(dev);
                uid_t uid = 0;
                gid_t gid = 0;
                mode_t mode = 0;
                bool perms = event_get_node_perms(event, &uid, &gid, &mode);

                if (major(devnum) > 0) {
                        _cleanup_free_ char *escaped = dump_escape(str);

                        fprintf(f, "%sDevice node:%s\n  %s (%s %u:%u)\n", ansi_highlight(), ansi_normal(), escaped ?: str,
                                streq_ptr(subsys, "block") ? "block" : "char", major(devnum), minor(devnum));
                }

                if (perms) {
                        struct passwd *pw = getpwuid(uid);
                        _cleanup_free_ char *escaped = pw ? dump_escape(pw->pw_name) : NULL;

                        fprintf(f, "%sDevice node owner user:%s\n  %s (uid="UID_FMT")\n", ansi_highlight(), ansi_normal(),
                                escaped ?: pw ? pw->pw_name : "n/a", uid);
                }

                if (perms) {
                        struct group *gr = getgrgid(gid);
                        _cleanup_free_ char *escaped = gr ? dump_escape(gr->gr_name) : NULL;

                        fprintf(f, "%sDevice node owner group:%s\n  %s (gid="GID_FMT")\n", ansi_highlight(), ansi_normal(),
                                escaped ?: gr ? gr->gr_name : "n/a", gid);
                }

                if (perms)
                        fprintf(f, "%sDevice node permission:%s\n  %04o\n", ansi_highlight(), ansi_normal(), mode);

                if (udev_device_get_devlinks_list_entry(dev)) {
                        fprintf(f, "%sDevice node symlinks:%s (priority=%i)\n", ansi_highlight(), ansi_normal(),
                                udev_device_get_devlink_priority(dev));
                        udev_list_entry_foreach(entry, udev_device_get_devlinks_list_entry(dev))
                                dump_value(f, udev_list_entry_get_name(entry));
                }

                if (udev_list_get_entry(&event->seclabel_list)) {
                        fprintf(f, "%sDevice node security label:%s\n", ansi_highlight(), ansi_normal());
                        udev_list_entry_foreach(entry, udev_list_get_entry(&event->seclabel_list))
                                dump_pair(f, udev_list_entry_get_name(entry), udev_list_entry_get_value(entry));
                }

                fprintf(f, "%sInotify watch:%s\n  %s\n", ansi_highlight(), ansi_normal(),
                        event->inotify_watch ? "enabled" : "disabled");
        }

        ifindex = udev_device_get_ifindex(dev);
        if (ifindex > 0) {
                fprintf(f, "%sNetwork interface index:%s\n  %i\n", ansi_highlight(), ansi_normal(), ifindex);

                if (!isempty(event->name))
                        dump_field(f, "Network interface name", event->name);

                /* like the reference implementation, all requested names, sorted, also the name of the interface */
                if (!strv_isempty(event->altnames)) {
                        fprintf(f, "%sAlternative interface names:%s\n", ansi_highlight(), ansi_normal());
                        STRV_FOREACH(p, strv_sort(event->altnames))
                                dump_value(f, *p);
                }
        }

        if (udev_list_get_entry(&event->written_sysattr_list)) {
                fprintf(f, "%sWritten sysfs attributes:%s\n", ansi_highlight(), ansi_normal());
                udev_list_entry_foreach(entry, udev_list_get_entry(&event->written_sysattr_list))
                        dump_pair(f, udev_list_entry_get_name(entry), udev_list_entry_get_value(entry));
        }

        if (udev_list_get_entry(&event->written_sysctl_list)) {
                fprintf(f, "%sWritten sysctl entries:%s\n", ansi_highlight(), ansi_normal());
                udev_list_entry_foreach(entry, udev_list_get_entry(&event->written_sysctl_list))
                        dump_pair(f, udev_list_entry_get_name(entry), udev_list_entry_get_value(entry));
        }

        if (udev_device_get_tags_list_entry(dev)) {
                fprintf(f, "%sTags:%s\n", ansi_highlight(), ansi_normal());
                udev_list_entry_foreach(entry, udev_device_get_tags_list_entry(dev))
                        dump_value(f, udev_list_entry_get_name(entry));
        }

        if (udev_device_get_current_tags_list_entry(dev)) {
                fprintf(f, "%sCurrent Tags:%s\n", ansi_highlight(), ansi_normal());
                udev_list_entry_foreach(entry, udev_device_get_current_tags_list_entry(dev))
                        dump_value(f, udev_list_entry_get_name(entry));
        }

        properties = dump_properties_strv(dev);
        if (!properties)
                return log_oom();
        fprintf(f, "%sProperties:%s\n", ansi_highlight(), ansi_normal());
        STRV_FOREACH(p, properties)
                dump_value(f, *p);

        if (udev_list_get_entry(&event->run_list)) {
                fprintf(f, "%sQueued commands:%s\n", ansi_highlight(), ansi_normal());
                udev_list_entry_foreach(entry, udev_list_get_entry(&event->run_list)) {
                        _cleanup_free_ char *escaped = dump_escape(udev_list_entry_get_name(entry));

                        fprintf(f, "  RUN{%s} : %s\n", udev_list_entry_get_num(entry) < UDEV_BUILTIN_MAX ? "builtin" : "program",
                                escaped ?: udev_list_entry_get_name(entry));
                }
        }

        return 0;
}
