/*
 * Copyright (C) IBM Corp. 2003
 * Copyright (C) SUSE Linux Products GmbH, 2006
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <getopt.h>
#include <sys/stat.h>

#include "build.h"
#include "libudev.h"
#include "device-nodes.h"
#include "fileio.h"
#include "libudev-private.h"
#include "options.h"
#include "scsi_id.h"
#include "strv.h"
#include "udev-util.h"
#include "utf8.h"

/* in the order of systemd's, which its message about an ambiguous option lists */
static const struct option options[] = {
        { "help",               no_argument,       NULL, 'h' },
        { "version",            no_argument,       NULL, 'V' }, /* don't advertise -V */
        { "device",             required_argument, NULL, 'd' },
        { "config",             required_argument, NULL, 'f' },
        { "page",               required_argument, NULL, 'p' },
        { "sg-version",         required_argument, NULL, 's' },
        { "denylisted",         no_argument,       NULL, 'b' },
        { "blacklisted",        no_argument,       NULL, 'b' }, /* backward compat */
        { "allowlisted",        no_argument,       NULL, 'g' },
        { "whitelisted",        no_argument,       NULL, 'g' }, /* backward compat */
        { "replace-whitespace", no_argument,       NULL, 'u' },
        { "verbose",            no_argument,       NULL, 'v' },
        { "export",             no_argument,       NULL, 'x' },
        {}
};

static const char optstring[] = "d:f:gp:uvVxhbs:";

static bool all_good = false;
static bool dev_specified = false;
static char config_file[MAX_PATH_LEN] = "/etc/scsi_id.config";
static enum page_code default_page_code = PAGE_UNSPECIFIED;
static int sg_version = 4;
static bool reformat_serial = false;
static bool export = false;
static char vendor_str[64];
static char model_str[64];
static char vendor_enc_str[256];
static char model_enc_str[256];
static char revision_str[16];
static char type_str[16];

static void set_type(unsigned type_num, char *to, size_t len) {
        const char *type;

        switch (type_num) {
        case 0:
                type = "disk";
                break;
        case 1:
                type = "tape";
                break;
        case 4:
                type = "optical";
                break;
        case 5:
                type = "cd";
                break;
        case 7:
                type = "optical";
                break;
        case 0xe:
                type = "disk";
                break;
        case 0xf:
                type = "optical";
                break;
        case 0x14:
                /*
                 * Use "zbc" here to be brief and consistent with "lsscsi" command.
                 * Other tools, e.g., "sg3_utils" would say "host managed zoned block".
                 */
                type = "zbc";
                break;
        default:
                type = "generic";
                break;
        }
        strscpy(to, len, type);
}

/*
 * get_file_options:
 *
 * If vendor == NULL, find a line in the config file with only "OPTIONS=";
 * if vendor and model are set find the first OPTIONS line in the config
 * file that matches. Set argc and argv to match the OPTIONS string.
 *
 * vendor and model can end in '\n'.
 */
static int get_file_options(struct udev *udev __attribute__((unused)),
                            const char *vendor, const char *model,
                            int *argc, char ***newargv)
{
        _cleanup_free_ char *vendor_in = NULL, *model_in = NULL, *options_in = NULL; /* read in from file */
        _cleanup_strv_free_ char **options_argv = NULL;
        int r;

        *newargv = NULL;

        _cleanup_fclose_ FILE *f = fopen(config_file, "re");
        if (!f) {
                if (errno == ENOENT)
                        return 1;
                return log_error_errno(errno, "Cannot open %s: %m", config_file);
        }

        for (int lineno = 0;;) {
                _cleanup_free_ char *buffer = NULL, *key = NULL, *value = NULL;
                const char *buf;

                r = read_line(f, MAX_BUFFER_LEN, &buffer);
                if (r < 0)
                        /* eudev: the number of the line that cannot be read, systemd gives the one before */
                        return log_error_errno(r, "read_line() on line %d of %s failed: %m", lineno + 1, config_file);
                if (r == 0)
                        break;
                buf = buffer;
                lineno++;

                while (isspace((unsigned char) *buf))
                        buf++;

                /* blank or all whitespace line */
                if (*buf == '\0')
                        continue;

                /* comment line */
                if (*buf == '#')
                        continue;

                r = extract_many_words(&buf, "=\",\n", 0, &key, &value);
                if (r < 2)
                        return log_error_errno(SYNTHETIC_ERRNO(EINVAL), "Error parsing config file %s line %d '%s'",
                                               config_file, lineno, buffer);

                if (strcaseeq(key, "VENDOR")) {
                        vendor_in = TAKE_PTR(value);

                        key = mfree(key);
                        /* eudev: white space after the comma is allowed, as in udev 3.2.x and before, e.g.
                         * 'vendor="ATA", options=-g'; systemd takes it as a part of the next key. buf is
                         * NULL at the end of the line. */
                        if (buf)
                                buf += strspn(buf, WHITESPACE);
                        r = extract_many_words(&buf, "=\",\n", 0, &key, &value);
                        if (r < 2)
                                return log_error_errno(SYNTHETIC_ERRNO(EINVAL), "Error parsing config file %s line %d '%s'",
                                                       config_file, lineno, buffer);

                        if (strcaseeq(key, "MODEL")) {
                                model_in = TAKE_PTR(value);

                                key = mfree(key);
                                if (buf) /* eudev, see above */
                                        buf += strspn(buf, WHITESPACE);
                                r = extract_many_words(&buf, "=\",\n", 0, &key, &value);
                                if (r < 2)
                                        return log_error_errno(SYNTHETIC_ERRNO(EINVAL), "Error parsing config file %s line %d '%s'",
                                                               config_file, lineno, buffer);
                        }
                }

                if (strcaseeq(key, "OPTIONS"))
                        options_in = TAKE_PTR(value);

                /*
                 * Only allow: [vendor=foo[,model=bar]]options=stuff
                 */
                if (!options_in || (!vendor_in && model_in))
                        return log_error_errno(SYNTHETIC_ERRNO(EINVAL), "Error parsing config file %s line %d '%s'",
                                               config_file, lineno, buffer);
                if (!vendor) {
                        if (!vendor_in)
                                break;
                } else if (vendor_in &&
                           startswith(vendor, vendor_in) &&
                           (!model_in || startswith(model, model_in))) {
                                /*
                                 * Matched vendor and optionally model.
                                 *
                                 * Note: a short vendor_in or model_in can
                                 * give a partial match (that is FOO
                                 * matches FOOBAR).
                                 */
                                break;
                }

                vendor_in = mfree(vendor_in);
                model_in = mfree(model_in);
                options_in = mfree(options_in);

        }

        if (!vendor_in && !model_in && !options_in)
                return 1; /* No matches  */

        /* Something matched. Allocate newargv, and store values found in options_in. */
        options_argv = strv_split(options_in, " \t");
        if (!options_argv)
                return log_oom();
        r = strv_prepend(&options_argv, ""); /* argv[0] is skipped */
        if (r < 0)
                return r;
        *newargv = TAKE_PTR(options_argv);
        *argc = strv_length(*newargv);

        return 0;
}

static void help(void) {
        (void) help_print("[DEVICE]", "Identify SCSI devices.",
                          "  -h --help                       Show this help\n"
                          "     --version                    Show package version\n"
                          "  -d --device=PATH                Device node for SG_IO commands\n"
                          "  -f --config=PATH                Location of config file\n"
                          "  -p --page=0x80|0x83|pre-spc3-83 SCSI page\n"
                          "  -s --sg-version=3|4             Use SGv3 or SGv4\n"
                          "  -b --denylisted                 Treat device as denylisted\n"
                          "  -g --allowlisted                Treat device as allowlisted\n"
                          "  -u --replace-whitespace         Replace all whitespace by underscores\n"
                          "  -v --verbose                    Verbose logging\n"
                          "  -x --export                     Print values as environment keys\n");
}

static int set_options(struct udev *udev __attribute__((unused)),
                       int argc, char **argv,
                       char *maj_min_dev)
{
        int option, r;

        /*
         * optind is a global extern used by getopt. Since we can call
         * set_options twice (once for command line, and once for config
         * file) we have to reset this back to 1.
         */
        optind = 1;
        while ((option = getopt_long_log(argc, argv, optstring, options)) >= 0)
                switch (option) {
                case 'b':
                        all_good = false;
                        break;

                case 'd':
                        dev_specified = true;
                        strscpy(maj_min_dev, MAX_PATH_LEN, optarg);
                        break;

                case 'f':
                        strscpy(config_file, MAX_PATH_LEN, optarg);
                        break;

                case 'g':
                        all_good = true;
                        break;

                case 'h':
                        help();
                        exit(0);

                case 'p':
                        if (streq(optarg, "0x80"))
                                default_page_code = PAGE_80;
                        else if (streq(optarg, "0x83"))
                                default_page_code = PAGE_83;
                        else if (streq(optarg, "pre-spc3-83"))
                                default_page_code = PAGE_83_PRE_SPC3;
                        else {
                                log_error("Unknown page code '%s'", optarg);
                                return -1;
                        }
                        break;

                case 's':
                        r = safe_atoi(optarg, &sg_version);
                        if (r < 0) {
                                log_error_errno(r, "Invalid SG version '%s'", optarg);
                                return -1;
                        }
                        if (sg_version < 3 || sg_version > 4) {
                                log_error("Unknown SG version '%s'", optarg);
                                return -1;
                        }
                        break;

                case 'u':
                        reformat_serial = true;
                        break;

                case 'v':
                        log_set_target(LOG_TARGET_CONSOLE);
                        log_set_max_level(LOG_DEBUG);
                        log_open();
                        break;

                case 'V':
                        (void) version();
                        exit(0);

                case 'x':
                        export = true;
                        break;

                case '?':
                        return -1;

                default:
                        assert_not_reached("Unknown option");
                }

        if (optind < argc && !dev_specified) {
                dev_specified = true;
                strscpy(maj_min_dev, MAX_PATH_LEN, argv[optind]);
        }

        return 0;
}

/* Like systemd: "Option -d/--device not supported in the config file.", with the short and the long name of
 * the option, as option_get_synopsis() of systemd gives them; arg is the argument the option was in. Unlike
 * systemd, which has a long option --version and a short option -V, eudev has one for both, whose name is
 * the one that was used. */
static void log_config_option_unsupported(int option, const char *arg) {
        int i;

        for (i = 0; options[i].name; i++)
                if (options[i].val == option)
                        break;
        assert(options[i].name);

        if (option == 'V')
                log_error("Option %s not supported in the config file.", startswith(arg, "--") ? "--version" : "-V");
        else
                log_error("Option -%c/--%s not supported in the config file.", option, options[i].name);
}

static int per_dev_options(struct udev *udev,
                           struct scsi_id_device *dev_scsi __attribute__((unused)), int *good_bad, int *page_code)
{
        _cleanup_strv_free_ char **newargv = NULL;
        int newargc;
        int option;
        int r;

        *good_bad = all_good;
        *page_code = default_page_code;

        /* Like systemd, an error in the config file, e.g. an invalid option in the line of the device, is
         * returned; no matching line is not an error. */
        r = get_file_options(udev, vendor_str, model_str, &newargc, &newargv);
        if (r != 0)
                return r < 0 ? r : 0;

        optind = 1; /* reset this global extern */
        for (;;) {
                /* Like systemd, all options are parsed, and those that are not allowed here refused. */
                option = getopt_long_log(newargc, newargv, optstring, options);
                if (option == -1)
                        break;

                switch (option) {
                case 'b':
                        *good_bad = 0;
                        break;

                case 'g':
                        *good_bad = 1;
                        break;

                case 'p':
                        if (streq(optarg, "0x80")) {
                                *page_code = PAGE_80;
                        } else if (streq(optarg, "0x83")) {
                                *page_code = PAGE_83;
                        } else if (streq(optarg, "pre-spc3-83")) {
                                *page_code = PAGE_83_PRE_SPC3;
                        } else
                                return log_error_errno(SYNTHETIC_ERRNO(EINVAL), "Unknown page code '%s'", optarg);
                        break;

                case '?':
                        /* logged already */
                        return -EINVAL;

                default:
                        log_config_option_unsupported(option, newargv[optind - 1]);
                        return -EINVAL;
                }
        }

        return 0;
}

static int set_inq_values(struct udev *udev, struct scsi_id_device *dev_scsi, const char *path)
{
        int retval;

        dev_scsi->use_sg = sg_version;

        retval = scsi_std_inquiry(udev, dev_scsi, path);
        if (retval)
                return retval;

        encode_devnode_name(dev_scsi->vendor, vendor_enc_str, sizeof(vendor_enc_str));
        encode_devnode_name(dev_scsi->model, model_enc_str, sizeof(model_enc_str));

        util_replace_whitespace(dev_scsi->vendor, vendor_str, sizeof(vendor_str));
        util_replace_chars(vendor_str, NULL);
        util_replace_whitespace(dev_scsi->model, model_str, sizeof(model_str));
        util_replace_chars(model_str, NULL);
        set_type(dev_scsi->type, type_str, sizeof(type_str));
        util_replace_whitespace(dev_scsi->revision, revision_str, sizeof(revision_str));
        util_replace_chars(revision_str, NULL);
        return 0;
}

static bool scsi_string_is_valid(const char *s) {
        return !isempty(s) && utf8_is_valid(s) && !string_has_cc(s, /* ok= */ NULL);
}

/*
 * scsi_id: try to get an id, if one is found, printf it to stdout.
 * returns a value passed to exit() - 0 if printed an id, else 1.
 */
static int scsi_id(struct udev *udev, char *maj_min_dev)
{
        struct scsi_id_device dev_scsi = {};
        int good_dev;
        int page_code;
        int retval = 0;

        if (set_inq_values(udev, &dev_scsi, maj_min_dev) != 0) {
                retval = 1;
                goto out;
        }

        /* get per device (vendor + model) options from the config file; like the reference implementation, fail if it cannot be
         * read, or the options of the device are invalid */
        if (per_dev_options(udev, &dev_scsi, &good_dev, &page_code) < 0) {
                retval = 1;
                goto out;
        }
        if (!good_dev) {
                retval = 1;
                goto out;
        }

        /* read serial number from mode pages (no values for optical drives) */
        scsi_get_serial(udev, &dev_scsi, maj_min_dev, page_code, MAX_SERIAL_LEN);

        if (export) {
                char serial_str[MAX_SERIAL_LEN];

                printf("ID_SCSI=1\n");
                printf("ID_VENDOR=%s\n", vendor_str);
                printf("ID_VENDOR_ENC=%s\n", vendor_enc_str);
                printf("ID_MODEL=%s\n", model_str);
                printf("ID_MODEL_ENC=%s\n", model_enc_str);
                printf("ID_REVISION=%s\n", revision_str);
                printf("ID_TYPE=%s\n", type_str);
                if (dev_scsi.serial[0] != '\0') {
                        util_replace_whitespace(dev_scsi.serial, serial_str, sizeof(serial_str));
                        util_replace_chars(serial_str, NULL);
                        printf("ID_SERIAL=%s\n", serial_str);
                        util_replace_whitespace(dev_scsi.serial_short, serial_str, sizeof(serial_str));
                        util_replace_chars(serial_str, NULL);
                        printf("ID_SERIAL_SHORT=%s\n", serial_str);
                }
                if (scsi_string_is_valid(dev_scsi.wwn)) {
                        printf("ID_WWN=0x%s\n", dev_scsi.wwn);
                        if (scsi_string_is_valid(dev_scsi.wwn_vendor_extension)) {
                                printf("ID_WWN_VENDOR_EXTENSION=0x%s\n", dev_scsi.wwn_vendor_extension);
                                printf("ID_WWN_WITH_EXTENSION=0x%s%s\n", dev_scsi.wwn, dev_scsi.wwn_vendor_extension);
                        } else {
                                printf("ID_WWN_WITH_EXTENSION=0x%s\n", dev_scsi.wwn);
                        }
                }
                if (scsi_string_is_valid(dev_scsi.tgpt_group)) {
                        printf("ID_TARGET_PORT=%s\n", dev_scsi.tgpt_group);
                }
                if (scsi_string_is_valid(dev_scsi.unit_serial_number)) {
                        printf("ID_SCSI_SERIAL=%s\n", dev_scsi.unit_serial_number);
                }
                goto out;
        }

        if (dev_scsi.serial[0] == '\0') {
                retval = 1;
                goto out;
        }

        if (reformat_serial) {
                char serial_str[MAX_SERIAL_LEN];

                util_replace_whitespace(dev_scsi.serial, serial_str, sizeof(serial_str));
                util_replace_chars(serial_str, NULL);
                printf("%s\n", serial_str);
                goto out;
        }

        printf("%s\n", dev_scsi.serial);
out:
        return retval;
}

int main(int argc, char **argv)
{
        _cleanup_udev_unref_ struct udev *udev;
        _cleanup_strv_free_ char **newargv = NULL;
        int retval = 0;
        char maj_min_dev[MAX_PATH_LEN];
        int newargc;

        udev = udev_new();
        /* like udev_parse_config() and log_setup() of systemd's helpers: after udev_log= of udev.conf, which
         * udev_new() applied, so that the environment, and the kernel command line, override it */
        log_parse_environment();
        log_open();
        if (!udev) {
                log_oom();
                retval = 1;
                goto exit;
        }

        /*
         * Get command line options first, so that the global options are read from the config file given
         * with -f/--config, and --help and --version work with a broken config file. (eudev; systemd reads
         * the global options from the default config file before it looks at the command line.)
         */
        if (set_options(udev, argc, argv, maj_min_dev) < 0)
                exit(1);

        /*
         * Get config file options.
         */
        retval = get_file_options(udev, NULL, NULL, &newargc, &newargv);
        if (retval < 0) {
                retval = 1;
                goto exit;
        }
        if (retval == 0) {
                assert(newargv);

                if (set_options(udev, newargc, newargv, maj_min_dev) < 0) {
                        retval = 2;
                        goto exit;
                }

                /*
                 * Get command line options again, they override any config file settings.
                 */
                if (set_options(udev, argc, argv, maj_min_dev) < 0)
                        exit(1);
        }

        if (!dev_specified) {
                log_error("No device specified.");
                retval = 1;
                goto exit;
        }

        retval = scsi_id(udev, maj_min_dev);

exit:
        log_close();
        return retval;
}
