# libudev-standalone

Clean-room implementation of the **libudev ABI**, built so existing libudev
clients (including **Y-libudev**) can link against a **systemd-free** device
manager without modification.

This is **route Y**: the companion library to
[udev-standalone](../udev-standalone) — the single `udev` binary that replaces
`udevd` + `udevadm` + `udev-hwdb`.

Licensed under
[TBWTFPL](https://github.com/Capricornus007/tbwtfpl) v114514 (only).

## How it talks to udev-standalone

No private protocol — it reads the same surfaces the daemon already exposes:

| Concern            | Source                                                        |
|--------------------|---------------------------------------------------------------|
| device properties  | `/run/udev/data/cMAJ:MIN`  (`E:KEY=VALUE` + `E:TAGS=`)        |
| queue state        | `/run/udev/queue`  (`SEQNUM=` + `QUEUE_LENGTH=`)              |
| kernel seqnum      | `/sys/kernel/uevent_seqnum`                                   |
| live monitoring    | netlink grp1 (kernel) / grp4 (daemon rebroadcast)             |
| device enumeration | scan `/run/udev/data/*` (one file per known device)          |

This mirrors how `libudev-zero` / `eudev` work: the library does **not** need a
special daemon IPC; it reads sysfs + the udev device DB directly.

## ABI completeness

The library exports **all 92 `udev_*` symbols from the official libudev ABI**,
each under the same version node as the real library:

| version node | symbols |
|---|---:|
| `LIBUDEV_183` | 82 |
| `LIBUDEV_189` | 1 |
| `LIBUDEV_196` | 4 (hwdb) |
| `LIBUDEV_199` | 1 |
| `LIBUDEV_215` | 2 (queue fd/flush) |
| `LIBUDEV_247` | 2 (current tags) |

The shared object is built with `SONAME=libudev.so.1` and installed as
`libudev.so.1.0.0` + `libudev.so.1` + `libudev.so`, so a binary that was linked
against the real system libudev loads this library unchanged (verified: a client
compiled with `-ludev` against systemd's libudev runs with
`LD_LIBRARY_PATH` pointing here). Seven extra non-official helpers
(`udev_get_dev_path`, `udev_queue_is_empty`, …) are exported under
`LIBUDEV_STANDALONE_1` for libudev-zero/eudev source compatibility.

## API

`src/udev.h` mirrors the standard libudev public API (function names and
signatures), so a program built against real libudev headers links unmodified:

- context: `udev_new/ref/unref`, `udev_get_dev_path/sys_path`, …
- device: `udev_device_new_from_devname/devnum/syspath/subsystem_sysname/device_id`,
  `udev_device_get_*`, `udev_device_get_properties_list_entry/tags_list_entry`,
  `udev_device_get_parent*`
- enumerate: `udev_enumerate_new`, `add_match_*`, `scan_devices`, `get_list_entry`
- monitor: `udev_monitor_new_from_netlink`, `enable_receiving`, `get_fd`,
  `receive_device`, `filter_add_match_*`
- queue: `udev_queue_new/ref/unref/get_udev`, `get_kernel_seqnum`,
  `get_udev_seqnum`, `get_udev_is_active`, `get_queue_is_empty`,
  `get_seqnum_is_finished`, `get_seqnum_sequence_is_finished`, `get_fd`,
  `flush`, plus the non-standard `get_queue_length` / `is_empty` / `wait`
- hwdb: `udev_hwdb_new/ref/unref`, `get_properties_list_entry` (text database,
  glob matching — no binary `hwdb.bin` required)
- util: `udev_util_encode_string` (safe-character encoding, UTF-8 aware)
- list entry: `udev_list_entry_get_next/by_name/name/value`

Every symbol in the official ABI is implemented and functional. A few optional
behaviours are deliberately simplified because this library reads the daemon's
state surfaces instead of a private IPC: in-kernel netlink filters are accepted
but not installed (all events are delivered to userspace), `get_sysattr_list_entry`
returns an empty list, and `get_parent` returns a referenced device rather than a
borrowed one. These do not affect normal enumeration, property, tag, monitor or
queue use.

## Build & test

Installation puts the public header at `$(PREFIX)/include/libudev.h`, the
SONAME tree in `$(PREFIX)/lib`, `libudev.pc` in `lib/pkgconfig` and `udev.pc` in
`share/pkgconfig` (both report version 262.1 for configure-script compatibility).

    make              # builds libudev.so.1.0.0 (+ .so.1/.so symlinks), libudev.a,
                      #        test/lutest, tools/udevinfo
    ./test/lutest     # self-contained: crafts a fake /run/udev root via UDEV_RUNDIR
    doas make install # installs the SONAME tree / libudev.a / udev.h / libudev.pc
                      #        (DESTDIR= and PREFIX= supported)

`test/lutest` exercises device lookup, property/tag enumeration, device
enumeration, and the queue API against a temporary `UDEV_RUNDIR` (no root
needed).

`tools/udevinfo` is a minimal `udevadm info` clone that links **only** against
`libudev.a` — proof of genuine drop-in compatibility:

    UDEV_RUNDIR=/tmp/fakeroot ./tools/udevinfo /dev/sda1
    UDEV_RUNDIR=/tmp/fakeroot ./tools/udevinfo --devnum b:8:1
    UDEV_RUNDIR=/tmp/fakeroot ./tools/udevinfo --queue   # SEQNUM / QUEUE_LENGTH

### End-to-end integration test (daemon → client)

`test/integration.sh` drives the real `udev-standalone` daemon (`apply`) and
reads the produced device DB with this library's `udevinfo`:

    UDEV_STANDALONE_BIN=/path/to/udev ./test/integration.sh

It asserts `ID_PATH`/`ID_PATH_TAG` (path_id builtin), `ID_FS_TYPE`/UUID/label
(blkid builtin), queue state (udev + daemon `udev queue`), the fake `/dev`
node, `udev verify` syntax checks, `udev test` dry-runs (uevent file + real
sysfs device), `udev test-builtin`, and argv[0] personalities (`udevadm` /
`udev-hwdb` symlinks), plus a venv-free ABI check: a client compiled against the
real system libudev runs against this library, and versioned symbols
(`LIBUDEV_183` / `LIBUDEV_247`) resolve. 47/47 checks pass.

## Status (route Y)

- [x] context + device (devname/devnum/syspath/subsystem_sysname/device_id)
- [x] properties, tags, sysattr, parent lookup
- [x] enumerate (scan_devices + match_subsystem/property/sysname/tag/sysattr/parent; scan_subsystems)
- [x] monitor (netlink grp1/grp4, receive_device)
- [x] queue (udev + kernel seqnum, length, is_empty, wait)
- [x] list entries
- [x] **name resolution fallback**: `udev_device_new_from_devname` scans the daemon's
      device DB under `UDEV_RUNDIR` when the real `/dev` node is absent (enables the
      end-to-end test without root)
- [x] `libudev.pc` pkg-config file + Makefile install (drop-in discovery on the target system)
- [x] **complete official ABI**: 92/92 `udev_*` symbols, exact `LIBUDEV_183`…`LIBUDEV_247`
      version nodes, `SONAME=libudev.so.1`, installed as a proper `.so.1.0.0` link tree
- [x] device current tags, devlinks, devtype, `usec_since_initialized`,
      `new_from_environment`, context userdata, `enumerate_add_syspath`
- [x] queue official surface: `get_udev_is_active`, `get_queue_is_empty`,
      `get_seqnum[_sequence]_is_finished`, `get_fd` (inotify), `flush`
- [x] hwdb text API (glob matching, no binary cache required)
- [x] `udev_util_encode_string` (UTF-8 aware safe-character encoding)
- [x] **all four udev DB key forms** — `b/c MAJ:MIN`, `nIFINDEX` (net),
      `+subsystem:sysname`; parses `S:` devlinks / `I:` init time / `E:` properties /
      `G:`+`Q:` tags, so enumeration and lookup also cover network interfaces and
      devices without a device number
