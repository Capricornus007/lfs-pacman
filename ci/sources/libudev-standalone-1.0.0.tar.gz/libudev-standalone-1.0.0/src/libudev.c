/*
 * libudev.c — clean-room implementation of the libudev ABI.
 *
 * Talks to udev-standalone (the systemd-free device manager) through the same
 * surfaces that daemon already exposes:
 *   - device DB : /run/udev/data/cMAJ:MIN   (E:KEY=VALUE + E:TAGS=)
 *   - queue     : /run/udev/queue           (SEQNUM + QUEUE_LENGTH)
 *   - kernel seq: /sys/kernel/uevent_seqnum
 *   - monitor   : netlink grp1 (kernel) / grp4 (daemon rebroadcast)
 *
 * Overridable for testing via env: UDEV_RUNDIR, UDEV_SYSFS_PATH.
 *
 * Licensed under TBWTFPL v114514 (https://github.com/Capricornus007/tbwtfpl).
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <time.h>
#include <fnmatch.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <sys/socket.h>
#include <sys/inotify.h>
#include <linux/netlink.h>
#include "udev.h"

extern char **environ;

/* ---------- paths (overridable for tests) ---------- */
static const char *rundir(void){ const char *e=getenv("UDEV_RUNDIR"); return e?e:"/run/udev"; }
static const char *sysfs_path(void){ const char *e=getenv("UDEV_SYSFS_PATH"); return e?e:"/sys"; }

/* list entry (defined early so device getters can build chains) */
struct udev_list_entry { char name[512]; char value[512]; struct udev_list_entry *next; };
static void free_list(struct udev_list_entry **head);
static struct udev_device *device_from_db_key(struct udev *udev, const char *key);

/* ===================== context ===================== */
struct udev { int refcount; char dev_path[32]; char sys_path[32]; void *userdata; };

struct udev *udev_new(void){
    struct udev *u = calloc(1,sizeof *u); if(!u) return NULL;
    u->refcount = 1;
    snprintf(u->dev_path,sizeof u->dev_path,"/dev");
    snprintf(u->sys_path,sizeof u->sys_path,"%s",sysfs_path());
    return u;
}
struct udev *udev_ref(struct udev *u){ if(u) u->refcount++; return u; }
struct udev *udev_unref(struct udev *u){ if(u && --u->refcount<=0){ free(u); return NULL; } return u; }
void *udev_get_userdata(struct udev *u){ return u?u->userdata:NULL; }
void udev_set_userdata(struct udev *u, void *userdata){ if(u) u->userdata=userdata; }
const char *udev_get_dev_path(struct udev *u){ return u?u->dev_path:"/dev"; }
const char *udev_get_sys_path(struct udev *u){ return u?u->sys_path:"/sys"; }
void udev_set_log_fn(struct udev *u, void (*fn)(struct udev*,int,const char*,int,const char*,const char*,va_list)){ (void)u;(void)fn; }
int udev_get_log_priority(struct udev *u){ (void)u; return 0; }
void udev_set_log_priority(struct udev *u, int p){ (void)u;(void)p; }

/* ===================== device ===================== */
#define MAX_PROP 256
struct udev_device {
    struct udev *udev; int refcount;
    char syspath[1024];
    char devpath[512];
    char subsystem[64];
    char sysname[256];
    char sysnum[64];
    char devnode[256];
    char action[32];
    char driver[64];
    char devtype_str[64];
    dev_t devnum; int devnum_valid;
    char devtype;            /* 'b' / 'c' / 0 */
    char prop_keys[MAX_PROP][64];
    char prop_vals[MAX_PROP][256];
    int nprops;
    char tags[32][64]; int ntags;
    char ctags[32][64]; int nctags;
    char devlinks[32][512]; int ndevlinks;
    uint64_t initialized_usec;   /* CLOCK_MONOTONIC, from the DB 'I:' line */
    struct udev_device *parent;
    int initialized;
    struct udev_list_entry *prop_list;  /* built on demand, freed on unref */
    struct udev_list_entry *tag_list;
    struct udev_list_entry *ctag_list;
    struct udev_list_entry *devlink_list;
};

static void set_property(struct udev_device *d, const char *k, const char *v){
    for(int i=0;i<d->nprops;i++) if(!strcmp(d->prop_keys[i],k)){ snprintf(d->prop_vals[i],256,"%s",v); return; }
    if(d->nprops<MAX_PROP){ snprintf(d->prop_keys[d->nprops],64,"%s",k); snprintf(d->prop_vals[d->nprops],256,"%s",v); d->nprops++; }
}
static const char *get_property(struct udev_device *d, const char *k){
    for(int i=0;i<d->nprops;i++) if(!strcmp(d->prop_keys[i],k)) return d->prop_vals[i];
    return NULL;
}

static void device_free_lists(struct udev_device *d){
    free_list(&d->prop_list);
    free_list(&d->tag_list);
    free_list(&d->ctag_list);
    free_list(&d->devlink_list);
}
static struct udev_device *device_alloc(struct udev *udev){
    struct udev_device *d = calloc(1,sizeof *d); if(!d) return NULL;
    d->udev = udev_ref(udev); d->refcount=1;
    return d;
}
struct udev *udev_get_udev(struct udev_device *d){ return d?d->udev:NULL; }
struct udev *udev_device_get_udev(struct udev_device *d){ return d?d->udev:NULL; }
struct udev_device *udev_device_ref(struct udev_device *d){ if(d) d->refcount++; return d; }
struct udev_device *udev_device_unref(struct udev_device *d){
    if(!d) return NULL;
    if(--d->refcount>0) return NULL;
    device_free_lists(d);
    if(d->parent) udev_device_unref(d->parent);
    udev_unref(d->udev);
    free(d);
    return NULL;
}

/* udev stores tags colon-separated (":uaccess:systemd:"); accept commas too so
   older/looser writers are parsed the same way. */
static void split_tags_into(const char *s, char arr[][64], int *n, int max){
    char buf[512]; snprintf(buf,sizeof buf,"%s",s);
    char *save=NULL, *t=strtok_r(buf,":,",&save);
    while(t && *n<max){ if(*t) snprintf(arr[(*n)++],64,"%s",t); t=strtok_r(NULL,":,",&save); }
}

/* udev database key: b/c MAJOR:MINOR, nIFINDEX for net, +subsystem:sysname. */
static int device_db_key(struct udev_device *d, char *out, size_t n){
    if(d->devnum_valid){
        char t = (d->devtype=='b' || !strcmp(d->subsystem,"block")) ? 'b' : 'c';
        snprintf(out,n,"%c%u:%u",t,major(d->devnum),minor(d->devnum));
        return 1;
    }
    if(!strcmp(d->subsystem,"net")){
        const char *ifidx=get_property(d,"IFINDEX");
        char buf[32];
        if((!ifidx||!*ifidx) && d->syspath[0]){
            char p[1300]; snprintf(p,sizeof p,"%s/ifindex",d->syspath);
            FILE *f=fopen(p,"r");
            if(f){ if(fscanf(f,"%31s",buf)!=1) buf[0]=0; fclose(f); if(buf[0]) ifidx=buf; }
        }
        if(ifidx && *ifidx){ snprintf(out,n,"n%s",ifidx); return 1; }
    }
    if(d->subsystem[0] && d->sysname[0]){ snprintf(out,n,"+%.60s:%.60s",d->subsystem,d->sysname); return 1; }
    return 0;
}
static void device_read_db_at(struct udev_device *d, const char *key){
    char path[512]; snprintf(path,sizeof path,"%s/data/%s",rundir(),key);
    FILE *f=fopen(path,"r"); if(!f) return;
    char line[1024];
    while(fgets(line,sizeof line,f)){
        size_t L=strlen(line); while(L&&(line[L-1]=='\n'||line[L-1]=='\r')) line[--L]=0;
        if(line[0]=='I' && line[1]==':'){ d->initialized_usec=strtoull(line+2,NULL,10); continue; }
        if(line[0]=='S' && line[1]==':'){
            const char *v=line+2;
            if(d->ndevlinks<32){
                if(v[0]=='/') snprintf(d->devlinks[d->ndevlinks],512,"%.511s",v);
                else snprintf(d->devlinks[d->ndevlinks],512,"/dev/%.506s",v);
                d->ndevlinks++;
            }
            continue;
        }
        if(line[0]=='G' && line[1]==':'){ if(d->ntags<32) snprintf(d->tags[d->ntags++],64,"%.63s",line+2); continue; }
        if(line[0]=='Q' && line[1]==':'){ if(d->nctags<32) snprintf(d->ctags[d->nctags++],64,"%.63s",line+2); continue; }
        if(strncmp(line,"E:",2)!=0) continue;
        char *p=line+2;
        if(!strncmp(p,"TAGS=",5)){ if(!d->ntags) split_tags_into(p+5,d->tags,&d->ntags,32); continue; }
        if(!strncmp(p,"CURRENT_TAGS=",13)){ if(!d->nctags) split_tags_into(p+13,d->ctags,&d->nctags,32); continue; }
        char *eq=strchr(p,'='); if(!eq) continue;
        *eq=0; const char *k=p, *v=eq+1;
        set_property(d,k,v);
        if(!strcmp(k,"SUBSYSTEM") && !d->subsystem[0]) snprintf(d->subsystem,sizeof d->subsystem,"%s",v);
        else if(!strcmp(k,"DEVPATH") && !d->devpath[0]) snprintf(d->devpath,sizeof d->devpath,"%s",v);
        else if(!strcmp(k,"DEVNAME") && !d->devnode[0]) snprintf(d->devnode,sizeof d->devnode,"/dev/%s",v);
        else if(!strcmp(k,"DRIVER") && !d->driver[0]) snprintf(d->driver,sizeof d->driver,"%s",v);
        else if(!strcmp(k,"DEVTYPE") && !d->devtype_str[0]) snprintf(d->devtype_str,sizeof d->devtype_str,"%s",v);
        else if(!strcmp(k,"DEVLINKS")){
            char buf[512]; snprintf(buf,sizeof buf,"%s",v);
            char *save=NULL, *t=strtok_r(buf," \t",&save);
            while(t && d->ndevlinks<32){ snprintf(d->devlinks[d->ndevlinks++],512,"%s",t); t=strtok_r(NULL," \t",&save); }
        }
    }
    fclose(f);
    d->initialized = 1;
}
static void device_read_db(struct udev_device *d){
    char key[128];
    if(device_db_key(d,key,sizeof key)) device_read_db_at(d,key);
}

/* fill convenience fields from sysfs (best effort; absent in --test) */
static void device_fill_syspath(struct udev_device *d){
    if(!d->syspath[0]) return;
    char *b=strrchr(d->syspath,'/'); if(b) snprintf(d->sysname,sizeof d->sysname,"%s",b+1);
    /* sysnum = trailing digits of sysname */
    if(d->sysname[0]){
        int n=strlen(d->sysname); int i=n;
        while(i>0 && d->sysname[i-1]>='0' && d->sysname[i-1]<='9') i--;
        if(i<n && i>0 && d->sysname[i-1]!='0') snprintf(d->sysnum,sizeof d->sysnum,"%s",d->sysname+i);
    }
    char sub[1200]; snprintf(sub,sizeof sub,"%s/subsystem",d->syspath);
    char link[256]; ssize_t n=readlink(sub,link,sizeof link-1);
    if(n>0){ link[n]=0; char *lb=strrchr(link,'/'); snprintf(d->subsystem,sizeof d->subsystem,"%.63s",lb?lb+1:link); }
    else { snprintf(sub,sizeof sub,"%s/../subsystem",d->syspath); n=readlink(sub,link,sizeof link-1);
        if(n>0){ link[n]=0; char *lb=strrchr(link,'/'); snprintf(d->subsystem,sizeof d->subsystem,"%.63s",lb?lb+1:link); } }
    char devp[1200]; snprintf(devp,sizeof devp,"%s/dev",d->syspath);
    FILE *f=fopen(devp,"r");
    if(f){ unsigned mj,mn; if(fscanf(f,"%u:%u",&mj,&mn)==2){ d->devnum=makedev(mj,mn); d->devnum_valid=1; } fclose(f); }
}

/* build a device from a dev_t by resolving its syspath via /sys/dev/{block,char} */
static struct udev_device *device_from_devnum(struct udev *udev, char type, dev_t devnum){
    struct udev_device *d=device_alloc(udev); if(!d) return NULL;
    d->devnum=devnum; d->devnum_valid=1; d->devtype=type;
    char sp[1100]; snprintf(sp,sizeof sp,"%s/dev/%s/%d:%d", sysfs_path(),(type=='b'?"block":"char"),major(devnum),minor(devnum));
    char link[1100]; ssize_t n=readlink(sp,link,sizeof link-1);
    if(n>0){ link[n]=0; char full[1300];
        if(link[0]=='/') snprintf(full,sizeof full,"%s",link);
        else snprintf(full,sizeof full,"%s/dev/%s/%s",sysfs_path(),(type=='b'?"block":"char"),link);
        char norm[1300]; if(realpath(full,norm)) snprintf(d->syspath,sizeof d->syspath,"%.1023s",norm);
        else snprintf(d->syspath,sizeof d->syspath,"%.1023s",full);
    }
    device_fill_syspath(d);
    device_read_db(d);
    return d;
}

struct udev_device *udev_device_new_from_devname(struct udev *udev, const char *devname){
    if(!udev||!devname) return NULL;
    char node[512];
    if(devname[0]=='/') snprintf(node,sizeof node,"%s",devname); else snprintf(node,sizeof node,"/dev/%s",devname);
    struct stat st;
    if(stat(node,&st)==0){
        struct udev_device *d=device_from_devnum(udev, S_ISBLK(st.st_mode)?'b':'c', st.st_rdev);
        if(d && !d->devnode[0]) snprintf(d->devnode,sizeof d->devnode,"%.255s",node);
        return d;
    }
    /* Fallback: the real /dev node is absent (e.g. a fake/test root produced by
       `udev apply`), so resolve the name by scanning the daemon's device DB in the
       rundir and matching on the DEVNAME the daemon recorded. This keeps libudev
       usable for end-to-end daemon→client tests without root or a real kernel. */
    const char *base=strrchr(node,'/'); base = base? base+1 : node;
    char dir[512]; snprintf(dir,sizeof dir,"%s/data",rundir());
    DIR *dp=opendir(dir); if(!dp) return NULL;
    struct dirent *e; struct udev_device *found=NULL;
    while((e=readdir(dp)) && !found){
        if(e->d_name[0]=='.') continue;
        struct udev_device *d=device_from_db_key(udev,e->d_name);
        if(!d) continue;
        const char *dn=udev_device_get_devnode(d);
        const char *db=dn?strrchr(dn,'/'):NULL; db=db?db+1:dn;
        if(dn && !strcmp(db?db:"",base)) found=d;
        else udev_device_unref(d);
    }
    closedir(dp);
    if(found && !found->devnode[0]) snprintf(found->devnode,sizeof found->devnode,"%.255s",node);
    return found;
}
struct udev_device *udev_device_new_from_devnum(struct udev *udev, char type, dev_t devnum){
    if(!udev) return NULL;
    return device_from_devnum(udev, type, devnum);
}
struct udev_device *udev_device_new_from_syspath(struct udev *udev, const char *syspath){
    if(!udev||!syspath) return NULL;
    struct udev_device *d=device_alloc(udev); if(!d) return NULL;
    snprintf(d->syspath,sizeof d->syspath,"%s",syspath);
    device_fill_syspath(d);
    device_read_db(d);
    return d;
}
struct udev_device *udev_device_new_from_subsystem_sysname(struct udev *udev, const char *subsystem, const char *sysname){
    if(!udev||!subsystem||!sysname) return NULL;
    char target[1300]; int ok=0;
    char cls[1300]; snprintf(cls,sizeof cls,"%s/class/%s/%s",sysfs_path(),subsystem,sysname);
    char link[1300]; ssize_t n=readlink(cls,link,sizeof link-1);
    if(n>0){ link[n]=0; char full[1400]; if(link[0]=='/') snprintf(full,sizeof full,"%s",link);
        else snprintf(full,sizeof full,"%s/class/%s/%s",sysfs_path(),subsystem,link);
        if(realpath(full,target)) ok=1; else { snprintf(target,sizeof target,"%.1299s",full); ok=1; } }
    else { snprintf(cls,sizeof cls,"%s/bus/%s/devices/%s",sysfs_path(),subsystem,sysname);
        n=readlink(cls,link,sizeof link-1);
        if(n>0){ link[n]=0; char full[1400]; if(link[0]=='/') snprintf(full,sizeof full,"%s",link);
            else snprintf(full,sizeof full,"%s/bus/%s/devices/%s",sysfs_path(),subsystem,link);
            if(realpath(full,target)) ok=1; else { snprintf(target,sizeof target,"%.1299s",full); ok=1; } } }
    if(!ok) return NULL;
    return udev_device_new_from_syspath(udev,target);
}
struct udev_device *udev_device_new_from_device_id(struct udev *udev, const char *id){
    if(!udev||!id||!id[0]) return NULL;
    return device_from_db_key(udev,id);
}
/* Recreate a device from an udev DB key: b/c MAJ:MIN, nIFINDEX, +subsystem:sysname.
   Falls back to a DB-only device when the sysfs entry is unavailable (fake root). */
static struct udev_device *device_from_db_key(struct udev *udev, const char *key){
    if(!udev||!key||!key[0]) return NULL;
    if(key[0]=='b'||key[0]=='c'){
        unsigned mj=0,mn=0;
        if(sscanf(key+1,"%u:%u",&mj,&mn)==2)
            return device_from_devnum(udev,key[0],makedev(mj,mn));
        return NULL;
    }
    if(key[0]=='n'){
        char base[600]; snprintf(base,sizeof base,"%s/class/net",sysfs_path());
        DIR *dp=opendir(base);
        if(dp){
            struct dirent *e;
            while((e=readdir(dp))){
                if(e->d_name[0]=='.') continue;
                char p[1300]; snprintf(p,sizeof p,"%s/%s/ifindex",base,e->d_name);
                FILE *f=fopen(p,"r"); if(!f) continue;
                char v[32]={0}; int ok=(fscanf(f,"%31s",v)==1); fclose(f);
                if(ok && !strcmp(v,key+1)){
                    char sp[1300]; snprintf(sp,sizeof sp,"%s/%s",base,e->d_name);
                    closedir(dp);
                    return udev_device_new_from_syspath(udev,sp);
                }
            }
            closedir(dp);
        }
    } else if(key[0]=='+'){
        const char *colon=strchr(key+1,':');
        if(colon){
            char sub[64]; size_t sl=(size_t)(colon-(key+1));
            if(sl>=sizeof sub) sl=sizeof sub-1;
            memcpy(sub,key+1,sl); sub[sl]=0;
            struct udev_device *d=udev_device_new_from_subsystem_sysname(udev,sub,colon+1);
            if(d) return d;
        }
    }
    struct udev_device *d=device_alloc(udev); if(!d) return NULL;
    if(key[0]=='+'){
        const char *colon=strchr(key+1,':');
        if(colon){
            size_t sl=(size_t)(colon-(key+1));
            if(sl>=sizeof d->subsystem) sl=sizeof d->subsystem-1;
            memcpy(d->subsystem,key+1,sl); d->subsystem[sl]=0;
            snprintf(d->sysname,sizeof d->sysname,"%s",colon+1);
        }
    } else if(key[0]=='n'){
        snprintf(d->subsystem,sizeof d->subsystem,"net");
    } else {
        udev_device_unref(d);
        return NULL;
    }
    device_read_db_at(d,key);
    if(!d->syspath[0] && d->devpath[0])
        { char sp[2048]; snprintf(sp,sizeof sp,"%s%s",sysfs_path(),d->devpath); snprintf(d->syspath,sizeof d->syspath,"%.1023s",sp); }
    return d;
}

struct udev_device *udev_device_new_from_environment(struct udev *udev){
    if(!udev) return NULL;
    const char *devpath=getenv("DEVPATH");
    if(!devpath || !devpath[0]) return NULL;
    char sp[1300]; snprintf(sp,sizeof sp,"%s%s",sysfs_path(),devpath);
    struct udev_device *d=udev_device_new_from_syspath(udev,sp);
    if(!d) return NULL;
    for(char **e=environ; e && *e; e++){
        const char *eq=strchr(*e,'='); if(!eq || eq==*e) continue;
        char k[64]; size_t kl=(size_t)(eq-*e); if(kl>=sizeof k) kl=sizeof k-1;
        memcpy(k,*e,kl); k[kl]=0;
        set_property(d,k,eq+1);
    }
    return d;
}

/* ---- getters ---- */
const char *udev_device_get_action(struct udev_device *d){ return d?d->action:NULL; }
const char *udev_device_get_devpath(struct udev_device *d){ return d? (d->devpath[0]?d->devpath: (d->syspath[0]?d->syspath+strlen(sysfs_path()):NULL)) : NULL; }
const char *udev_device_get_syspath(struct udev_device *d){ return d?d->syspath:NULL; }
const char *udev_device_get_sysname(struct udev_device *d){ return d?d->sysname:NULL; }
const char *udev_device_get_sysnum(struct udev_device *d){ return d?d->sysnum:NULL; }
const char *udev_device_get_devnode(struct udev_device *d){ return d? (d->devnode[0]?d->devnode:NULL) : NULL; }
const char *udev_device_get_subsystem(struct udev_device *d){ return d? (d->subsystem[0]?d->subsystem:get_property(d,"SUBSYSTEM")) : NULL; }
const char *udev_device_get_driver(struct udev_device *d){ return d? (d->driver[0]?d->driver:NULL) : NULL; }
const char *udev_device_get_devtype(struct udev_device *d){
    if(!d) return NULL;
    if(d->devtype_str[0]) return d->devtype_str;
    const char *p=get_property(d,"DEVTYPE");
    if(p && p[0]){ snprintf(d->devtype_str,sizeof d->devtype_str,"%s",p); return d->devtype_str; }
    if(d->syspath[0]){
        char uev[1300]; snprintf(uev,sizeof uev,"%s/uevent",d->syspath);
        FILE *f=fopen(uev,"r");
        if(f){ char line[512];
            while(fgets(line,sizeof line,f)){
                if(!strncmp(line,"DEVTYPE=",8)){
                    size_t L=strlen(line+8); while(L&&(line[8+L-1]=='\n'||line[8+L-1]=='\r')) L--;
                    if(L<sizeof d->devtype_str){ memcpy(d->devtype_str,line+8,L); d->devtype_str[L]=0; }
                    break;
                }
            }
            fclose(f);
        }
    }
    return d->devtype_str[0]?d->devtype_str:NULL;
}
dev_t udev_device_get_devnum(struct udev_device *d){ return d? d->devnum : makedev(0,0); }
unsigned long long udev_device_get_seqnum(struct udev_device *d){ if(!d) return 0; const char *s=get_property(d,"SEQNUM"); return s? strtoull(s,NULL,10):0; }
unsigned long long udev_device_get_usec_since_initialized(struct udev_device *d){
    if(!d || !d->initialized_usec) return 0;
    struct timespec ts;
    if(clock_gettime(CLOCK_MONOTONIC,&ts)!=0) return 0;
    uint64_t now=(uint64_t)ts.tv_sec*1000000ull + (uint64_t)ts.tv_nsec/1000ull;
    return now>d->initialized_usec ? now-d->initialized_usec : 0;
}
const char *udev_device_get_property_value(struct udev_device *d, const char *key){ return d?get_property(d,key):NULL; }
const char *udev_device_get_sysattr_value(struct udev_device *d, const char *attr){
    if(!d||!d->syspath[0]||!attr) return NULL;
    char p[1300]; snprintf(p,sizeof p,"%s/%s",d->syspath,attr);
    FILE *f=fopen(p,"r"); if(!f) return NULL;
    static char buf[1024]; size_t n=fread(buf,1,sizeof buf-1,f); fclose(f);
    if(n>0 && buf[n-1]=='\n') n--;
    buf[n]=0;
    return buf[0]?buf:NULL;
}
int udev_device_set_sysattr_value(struct udev_device *d, const char *attr, const char *value){
    if(!d||!d->syspath[0]||!attr) return -1;
    char p[1300]; snprintf(p,sizeof p,"%s/%s",d->syspath,attr);
    FILE *f=fopen(p,"w"); if(!f) return -1; if(value) fputs(value,f); fclose(f); return 0;
}
int udev_device_has_tag(struct udev_device *d, const char *tag){
    if(!d||!tag) return 0;
    for(int i=0;i<d->ntags;i++) if(!strcmp(d->tags[i],tag)) return 1;
    return 0;
}
int udev_device_has_current_tag(struct udev_device *d, const char *tag){
    if(!d||!tag) return 0;
    for(int i=0;i<d->nctags;i++) if(!strcmp(d->ctags[i],tag)) return 1;
    return 0;
}
int udev_device_get_is_initialized(struct udev_device *d){ return d?d->initialized:0; }

struct udev_device *udev_device_get_parent(struct udev_device *d){
    if(!d||!d->syspath[0]) return NULL;
    char parent[1300]; snprintf(parent,sizeof parent,"%s",d->syspath);
    char *slash=strrchr(parent,'/'); if(!slash||slash==parent) return NULL;
    *slash=0;
    return udev_device_new_from_syspath(d->udev,parent);
}
struct udev_device *udev_device_get_parent_with_subsystem_devtype(struct udev_device *d, const char *subsystem, const char *devtype){
    (void)devtype;
    struct udev_device *p=udev_device_get_parent(d);
    while(p){
        const char *s=udev_device_get_subsystem(p);
        if(s && subsystem && !strcmp(s,subsystem)) return p;
        struct udev_device *pp=udev_device_get_parent(p);
        udev_device_unref(p); p=pp;
    }
    return NULL;
}

/* build a udev_list_entry chain from properties / tags (cached, freed on unref) */
static void free_list(struct udev_list_entry **head){
    while(*head){ struct udev_list_entry *n=(*head)->next; free(*head); *head=n; }
}
static struct udev_list_entry *device_prop_list(struct udev_device *d){
    free_list(&d->prop_list);
    for(int i=0;i<d->nprops;i++){
        struct udev_list_entry *e=malloc(sizeof *e); if(!e) break;
        snprintf(e->name,sizeof e->name,"%s",d->prop_keys[i]);
        snprintf(e->value,sizeof e->value,"%s",d->prop_vals[i]);
        e->next=d->prop_list; d->prop_list=e;
    }
    return d->prop_list;
}
static struct udev_list_entry *device_tag_list(struct udev_device *d){
    free_list(&d->tag_list);
    for(int i=d->ntags-1;i>=0;i--){
        struct udev_list_entry *e=malloc(sizeof *e); if(!e) break;
        snprintf(e->name,sizeof e->name,"%s",d->tags[i]); e->value[0]=0;
        e->next=d->tag_list; d->tag_list=e;
    }
    return d->tag_list;
}
static struct udev_list_entry *device_ctag_list(struct udev_device *d){
    free_list(&d->ctag_list);
    for(int i=d->nctags-1;i>=0;i--){
        struct udev_list_entry *e=malloc(sizeof *e); if(!e) break;
        snprintf(e->name,sizeof e->name,"%s",d->ctags[i]); e->value[0]=0;
        e->next=d->ctag_list; d->ctag_list=e;
    }
    return d->ctag_list;
}
static struct udev_list_entry *device_devlink_list(struct udev_device *d){
    free_list(&d->devlink_list);
    for(int i=d->ndevlinks-1;i>=0;i--){
        struct udev_list_entry *e=malloc(sizeof *e); if(!e) break;
        snprintf(e->name,sizeof e->name,"%s",d->devlinks[i]); e->value[0]=0;
        e->next=d->devlink_list; d->devlink_list=e;
    }
    return d->devlink_list;
}
struct udev_list_entry *udev_device_get_properties_list_entry(struct udev_device *d){ return d?device_prop_list(d):NULL; }
struct udev_list_entry *udev_device_get_tags_list_entry(struct udev_device *d){ return d?device_tag_list(d):NULL; }
struct udev_list_entry *udev_device_get_current_tags_list_entry(struct udev_device *d){ return d?device_ctag_list(d):NULL; }
struct udev_list_entry *udev_device_get_devlinks_list_entry(struct udev_device *d){ return d?device_devlink_list(d):NULL; }
struct udev_list_entry *udev_device_get_sysattr_list_entry(struct udev_device *d){ (void)d; return NULL; }

/* ===================== list entry ===================== */
struct udev_list_entry *udev_list_entry_get_next(struct udev_list_entry *e){ return e?e->next:NULL; }
struct udev_list_entry *udev_list_entry_get_by_name(struct udev_list_entry *e, const char *name){
    for(; e; e=e->next)
        if(!strcmp(e->name,name)) return e;
    return NULL;
}
const char *udev_list_entry_get_name(struct udev_list_entry *e){ return e?e->name:NULL; }
const char *udev_list_entry_get_value(struct udev_list_entry *e){ return e?e->value:NULL; }

/* ===================== enumerate ===================== */
struct udev_enumerate {
    struct udev *udev; int refcount;
    char match_subsys[16][64]; int nmatch_subsys;
    char nomatch_subsys[16][64]; int nno_subsys;
    char match_prop[16][64]; char match_prop_val[16][256]; int nmatch_prop;
    char match_sysname[64];
    char match_tag[64];
    char match_sysattr[16][64];
    char match_sysattr_val[16][256]; int nmatch_sysattr;
    char syspaths[16][1024]; int nsyspaths;
    struct udev_device *parent;
    struct udev_list_entry *list;
};
struct udev_enumerate *udev_enumerate_new(struct udev *udev){ if(!udev) return NULL; struct udev_enumerate *e=calloc(1,sizeof *e); if(!e) return NULL; e->udev=udev_ref(udev); e->refcount=1; return e; }
struct udev_enumerate *udev_enumerate_ref(struct udev_enumerate *e){ if(e) e->refcount++; return e; }
struct udev_enumerate *udev_enumerate_unref(struct udev_enumerate *e){
    if(!e) return NULL;
    if(--e->refcount>0) return NULL;
    while(e->list){ struct udev_list_entry *n=e->list->next; free(e->list); e->list=n; }
    if(e->parent) udev_device_unref(e->parent);
    udev_unref(e->udev); free(e); return NULL;
}
int udev_enumerate_add_match_subsystem(struct udev_enumerate *e, const char *s){ if(e&&e->nmatch_subsys<16&&s) snprintf(e->match_subsys[e->nmatch_subsys++],64,"%s",s); return 0; }
int udev_enumerate_add_nomatch_subsystem(struct udev_enumerate *e, const char *s){ if(e&&e->nno_subsys<16&&s) snprintf(e->nomatch_subsys[e->nno_subsys++],64,"%s",s); return 0; }
int udev_enumerate_add_match_sysattr(struct udev_enumerate *e, const char *a, const char *v){
    if(e&&e->nmatch_sysattr<16&&a){ snprintf(e->match_sysattr[e->nmatch_sysattr],64,"%s",a); snprintf(e->match_sysattr_val[e->nmatch_sysattr],256,"%s",v?v:""); e->nmatch_sysattr++; } return 0;
}
int udev_enumerate_add_nomatch_sysattr(struct udev_enumerate *e, const char *a, const char *v){ (void)e;(void)a;(void)v; return 0; }
int udev_enumerate_add_match_property(struct udev_enumerate *e, const char *p, const char *v){ if(e&&e->nmatch_prop<16&&p) { snprintf(e->match_prop[e->nmatch_prop],64,"%s",p); snprintf(e->match_prop_val[e->nmatch_prop],256,"%s",v?v:""); e->nmatch_prop++; } return 0; }
int udev_enumerate_add_match_sysname(struct udev_enumerate *e, const char *s){ if(e) snprintf(e->match_sysname,64,"%s",s?s:""); return 0; }
int udev_enumerate_add_match_tag(struct udev_enumerate *e, const char *t){ if(e) snprintf(e->match_tag,64,"%s",t?t:""); return 0; }
int udev_enumerate_add_match_parent(struct udev_enumerate *e, struct udev_device *p){
    if(e){ if(e->parent) udev_device_unref(e->parent); e->parent = p?udev_device_ref(p):NULL; } return 0;
}
int udev_enumerate_add_match_is_initialized(struct udev_enumerate *e){ (void)e; return 0; }
struct udev *udev_enumerate_get_udev(struct udev_enumerate *e){ return e?e->udev:NULL; }
int udev_enumerate_add_syspath(struct udev_enumerate *e, const char *syspath){
    if(!e||!syspath) return -1;
    if(e->nsyspaths<16) snprintf(e->syspaths[e->nsyspaths++],1024,"%s",syspath);
    return 0;
}

static int enum_matches(struct udev_enumerate *e, struct udev_device *d){
    for(int i=0;i<e->nmatch_subsys;i++){ const char *s=udev_device_get_subsystem(d); if(!s||strcmp(s,e->match_subsys[i])) return 0; }
    for(int i=0;i<e->nno_subsys;i++){ const char *s=udev_device_get_subsystem(d); if(s&&!strcmp(s,e->nomatch_subsys[i])) return 0; }
    for(int i=0;i<e->nmatch_prop;i++){ const char *v=udev_device_get_property_value(d,e->match_prop[i]); if(!v||strcmp(v,e->match_prop_val[i])) return 0; }
    if(e->match_sysname[0]){ const char *n=udev_device_get_sysname(d); if(!n||strcmp(n,e->match_sysname)) return 0; }
    if(e->match_tag[0]){ if(!udev_device_has_tag(d,e->match_tag)) return 0; }
    for(int i=0;i<e->nmatch_sysattr;i++){
        const char *val=udev_device_get_sysattr_value(d,e->match_sysattr[i]);
        if(!val) return 0;
        if(e->match_sysattr_val[i][0] && strcmp(val,e->match_sysattr_val[i])) return 0;
    }
    if(e->parent){
        const char *psp=udev_device_get_syspath(e->parent);
        int found=0; struct udev_device *pp=udev_device_ref(d);
        while(pp){ const char *sp=udev_device_get_syspath(pp);
            if(sp&&psp&&!strcmp(sp,psp)){ found=1; break; }
            struct udev_device *gp=udev_device_get_parent(pp); udev_device_unref(pp); pp=gp; }
        if(!found) return 0;
    }
    return 1;
}
int udev_enumerate_scan_devices(struct udev_enumerate *e){
    if(!e) return -1;
    char dir[512]; snprintf(dir,sizeof dir,"%s/data", rundir());
    DIR *d=opendir(dir); if(!d) return 0;
    struct dirent *ent;
    while((ent=readdir(d))){
        if(ent->d_name[0]=='.') continue;
        struct udev_device *dev=device_from_db_key(e->udev,ent->d_name);
        if(!dev) continue;
        if(enum_matches(e,dev)){
            struct udev_list_entry *le=malloc(sizeof *le); if(le){
                snprintf(le->name,sizeof le->name,"%.511s",dev->syspath[0]?dev->syspath:"/devices");
                snprintf(le->value,sizeof le->value,"%.511s",dev->devnode[0]?dev->devnode:"");
                le->next=e->list; e->list=le;
            }
        }
        udev_device_unref(dev);
    }
    closedir(d);
    /* explicitly added syspaths are part of the result set too */
    for(int k=0;k<e->nsyspaths;k++){
        int dup=0;
        for(struct udev_list_entry *le=e->list; le; le=le->next)
            if(!strcmp(le->name,e->syspaths[k])){ dup=1; break; }
        if(dup) continue;
        struct udev_device *dev=udev_device_new_from_syspath(e->udev,e->syspaths[k]);
        if(!dev) continue;
        if(enum_matches(e,dev)){
            struct udev_list_entry *le=malloc(sizeof *le); if(le){
                snprintf(le->name,sizeof le->name,"%.511s",dev->syspath[0]?dev->syspath:e->syspaths[k]);
                snprintf(le->value,sizeof le->value,"%.511s",dev->devnode[0]?dev->devnode:"");
                le->next=e->list; e->list=le;
            }
        }
        udev_device_unref(dev);
    }
    return 0;
}
int udev_enumerate_scan_subsystems(struct udev_enumerate *e){
    if(!e) return -1;
    const char *bases[2] = {"class","bus"};
    for(int b=0;b<2;b++){
        char dir[512]; snprintf(dir,sizeof dir,"%s/%s",sysfs_path(),bases[b]);
        DIR *d=opendir(dir); if(!d) continue;
        struct dirent *ent;
        while((ent=readdir(d))){
            if(!strcmp(ent->d_name,".")||!strcmp(ent->d_name,"..")) continue;
            struct udev_list_entry *le=malloc(sizeof *le); if(!le) continue;
            snprintf(le->name,sizeof le->name,"%s",ent->d_name);
            snprintf(le->value,sizeof le->value,"%s",bases[b]);
            le->next=e->list; e->list=le;
        }
        closedir(d);
    }
    return 0;
}
struct udev_list_entry *udev_enumerate_get_list_entry(struct udev_enumerate *e){ return e?e->list:NULL; }

/* ===================== monitor ===================== */
struct udev_monitor {
    struct udev *udev; int refcount; int fd; int group; int receiving;
};
struct udev_monitor *udev_monitor_new_from_netlink(struct udev *udev, const char *name){
    if(!udev) return NULL;
    int grp = (!name||!strcmp(name,"kernel")) ? 1 : (!strcmp(name,"udev") ? 4 : 1);
    int fd=socket(AF_NETLINK,SOCK_RAW,NETLINK_KOBJECT_UEVENT);
    if(fd<0) return NULL;
    struct sockaddr_nl nl; memset(&nl,0,sizeof nl);
    nl.nl_family=AF_NETLINK; nl.nl_groups=grp;
    if(bind(fd,(struct sockaddr*)&nl,sizeof nl)<0){ close(fd); return NULL; }
    struct udev_monitor *m=calloc(1,sizeof *m); if(!m){ close(fd); return NULL; }
    m->udev=udev_ref(udev); m->refcount=1; m->fd=fd; m->group=grp;
    return m;
}
struct udev_monitor *udev_monitor_ref(struct udev_monitor *m){ if(m) m->refcount++; return m; }
struct udev_monitor *udev_monitor_unref(struct udev_monitor *m){
    if(!m) return NULL;
    if(--m->refcount>0) return NULL;
    if(m->fd>=0) close(m->fd);
    udev_unref(m->udev);
    free(m);
    return NULL;
}
struct udev *udev_monitor_get_udev(struct udev_monitor *m){ return m?m->udev:NULL; }
int udev_monitor_enable_receiving(struct udev_monitor *m){ if(!m) return -1; m->receiving=1; return 0; }
int udev_monitor_set_receive_buffer_size(struct udev_monitor *m, int size){ (void)m;(void)size; return 0; }
int udev_monitor_get_fd(struct udev_monitor *m){ return m?m->fd:-1; }
int udev_monitor_filter_add_match_subsystem_devtype(struct udev_monitor *m, const char *s, const char *dt){ (void)m;(void)s;(void)dt; return 0; }
int udev_monitor_filter_add_match_tag(struct udev_monitor *m, const char *t){ (void)m;(void)t; return 0; }
int udev_monitor_filter_update(struct udev_monitor *m){ (void)m; return 0; }
int udev_monitor_filter_remove(struct udev_monitor *m){ (void)m; return 0; }

struct udev_device *udev_monitor_receive_device(struct udev_monitor *m){
    if(!m) return NULL;
    char buf[8192]; ssize_t n=recv(m->fd,buf,sizeof buf-1,0);
    if(n<=0) return NULL;
    const char *p=buf,*end=buf+n;
    const char *nl=memchr(p,'\0',end-p); if(!nl) return NULL;
    size_t fl=nl-p; const char *at=memchr(p,'@',fl);
    struct udev_device *d=device_alloc(m->udev); if(!d) return NULL;
    if(at){ size_t al=at-p; if(al<sizeof d->action-1){ memcpy(d->action,p,al); d->action[al]=0; }
           size_t dl=fl-al-1; if(dl<sizeof d->devpath-1){ memcpy(d->devpath,at+1,dl); d->devpath[dl]=0; } }
    else { if(fl<sizeof d->action-1){ memcpy(d->action,p,fl); d->action[fl]=0; } }
    p=nl+1; unsigned mj=0,mn=0; int have_dev=0;
    while(p<end && *p){
        const char *nnl=memchr(p,'\0',end-p); if(!nnl) break;
        size_t l=nnl-p; char kv[512]; if(l<sizeof kv) memcpy(kv,p,l); kv[l]=0;
        char *eq=strchr(kv,'=');
        if(eq){ *eq=0; const char *k=kv,*v=eq+1; set_property(d,k,v);
            if(!strcmp(k,"SUBSYSTEM")&&!d->subsystem[0]) snprintf(d->subsystem,sizeof d->subsystem,"%s",v);
            else if(!strcmp(k,"DEVPATH")&&!d->devpath[0]) snprintf(d->devpath,sizeof d->devpath,"%s",v);
            else if(!strcmp(k,"DEVNAME")&&!d->devnode[0]) snprintf(d->devnode,sizeof d->devnode,"/dev/%s",v);
            else if(!strcmp(k,"MAJOR")) mj=(unsigned)strtoul(v,NULL,10);
            else if(!strcmp(k,"MINOR")) mn=(unsigned)strtoul(v,NULL,10);
        }
        p=nnl+1;
    }
    if(mj||mn){ d->devnum=makedev(mj,mn); d->devnum_valid=1; have_dev=1; }
    (void)have_dev;
    /* fill sysfs fields first: the DB key for net needs the ifindex/sysname */
    if(d->devpath[0]){ char sp[1300]; snprintf(sp,sizeof sp,"%s%s",sysfs_path(),d->devpath); snprintf(d->syspath,sizeof d->syspath,"%.1023s",sp); device_fill_syspath(d); }
    device_read_db(d);
    return d;
}

/* ===================== queue ===================== */
struct udev_queue { struct udev *udev; int refcount; int fd; };
struct udev_queue *udev_queue_new(struct udev *udev){ if(!udev) return NULL; struct udev_queue *q=calloc(1,sizeof *q); if(!q) return NULL; q->udev=udev_ref(udev); q->refcount=1; q->fd=-1; return q; }
struct udev_queue *udev_queue_ref(struct udev_queue *q){ if(q) q->refcount++; return q; }
struct udev_queue *udev_queue_unref(struct udev_queue *q){ if(!q) return NULL; if(--q->refcount>0) return NULL; if(q->fd>=0) close(q->fd); udev_unref(q->udev); free(q); return NULL; }
struct udev *udev_queue_get_udev(struct udev_queue *q){ return q?q->udev:NULL; }

static unsigned long long read_num_file(const char *path){
    FILE *f=fopen(path,"r"); if(!f) return 0;
    unsigned long long v=0; if(fscanf(f,"%llu",&v)!=1) v=0; fclose(f); return v;
}
unsigned long long udev_queue_get_kernel_seqnum(struct udev_queue *q){
    (void)q; char p[512]; snprintf(p,sizeof p,"%s/kernel/uevent_seqnum",sysfs_path()); return read_num_file(p);
}
unsigned long long udev_queue_get_udev_seqnum(struct udev_queue *q){
    (void)q; char p[512]; snprintf(p,sizeof p,"%s/queue",rundir());
    unsigned long long seq=0; int got=0;
    FILE *f=fopen(p,"r"); if(f){ char line[256]; while(fgets(line,sizeof line,f)){ if(!strncmp(line,"SEQNUM=",7)){ seq=strtoull(line+7,NULL,10); got=1; break; } } fclose(f); }
    return got?seq:0;
}
int udev_queue_get_queue_length(struct udev_queue *q){
    (void)q; char p[512]; snprintf(p,sizeof p,"%s/queue",rundir());
    int len=0; FILE *f=fopen(p,"r"); if(f){ char line[256]; while(fgets(line,sizeof line,f)){ if(!strncmp(line,"QUEUE_LENGTH=",13)){ len=(int)strtol(line+13,NULL,10); break; } } fclose(f); }
    return len;
}
int udev_queue_is_empty(struct udev_queue *q){ return udev_queue_get_queue_length(q)==0; }
int udev_queue_wait(struct udev_queue *q){
    while(!udev_queue_is_empty(q)) usleep(50000);
    return 0;
}

/* ---- official libudev queue surface ---- */
int udev_queue_get_udev_is_active(struct udev_queue *q){
    (void)q;
    if(access("/run/udev/control",F_OK)==0) return 1;
    FILE *f=fopen("/run/udev.pid","r");
    if(f){ long pid=0; int ok=(fscanf(f,"%ld",&pid)==1 && pid>0); fclose(f);
        return ok && kill((pid_t)pid,0)==0; }
    return 0;
}
int udev_queue_get_queue_is_empty(struct udev_queue *q){ return udev_queue_is_empty(q); }
int udev_queue_get_seqnum_is_finished(struct udev_queue *q, unsigned long long seqnum){
    (void)seqnum; return udev_queue_is_empty(q);
}
int udev_queue_get_seqnum_sequence_is_finished(struct udev_queue *q, unsigned long long start, unsigned long long end){
    (void)start; (void)end; return udev_queue_is_empty(q);
}
int udev_queue_get_fd(struct udev_queue *q){
    if(!q) return -EINVAL;
    if(q->fd>=0) return q->fd;
    int fd=inotify_init1(IN_CLOEXEC|IN_NONBLOCK);
    if(fd<0) return -errno;
    if(inotify_add_watch(fd,rundir(),IN_MODIFY|IN_CLOSE_WRITE|IN_CREATE|IN_DELETE|IN_MOVED_TO)<0){
        int e=errno; close(fd); return -e;
    }
    q->fd=fd;
    return fd;
}
int udev_queue_flush(struct udev_queue *q){
    if(!q) return -EINVAL;
    if(q->fd<0) return -EINVAL;
    char buf[4096];
    while(read(q->fd,buf,sizeof buf)>0){}
    return 0;
}
struct udev_list_entry *udev_queue_get_queued_list_entry(struct udev_queue *q){
    (void)q; errno=ENODATA; return NULL;
}

/* ===================== hwdb (text database) ===================== */
#define HWDB_MAX_PROPS 32
struct hwdb_prop { char key[64]; char val[256]; };
struct hwdb_entry { char match[256]; struct hwdb_prop props[HWDB_MAX_PROPS]; int nprops; };
struct udev_hwdb {
    struct udev *udev; int refcount;
    struct hwdb_entry *entries; int n, cap;
    int loaded;
    struct udev_list_entry *list;
};

static void hwdb_add_entry(struct udev_hwdb *h, const char *match){
    if(h->n==h->cap){
        int nc=h->cap?h->cap*2:64;
        struct hwdb_entry *ne=realloc(h->entries,(size_t)nc*sizeof *ne);
        if(!ne) return;
        h->entries=ne; h->cap=nc;
    }
    struct hwdb_entry *e=&h->entries[h->n++];
    memset(e,0,sizeof *e);
    snprintf(e->match,sizeof e->match,"%s",match);
}
static void hwdb_load_file(struct udev_hwdb *h, const char *path){
    FILE *f=fopen(path,"r"); if(!f) return;
    char line[1024]; struct hwdb_entry *cur=NULL;
    while(fgets(line,sizeof line,f)){
        size_t L=strlen(line); while(L&&(line[L-1]=='\n'||line[L-1]=='\r')) line[--L]=0;
        if(!L) continue;
        if(line[0]==' '||line[0]=='\t'){
            if(!cur) continue;
            char *s=line; while(*s==' '||*s=='\t') s++;
            if(*s=='#'||!*s) continue;
            char *eq=strchr(s,'='); if(!eq) continue;
            *eq=0;
            if(cur->nprops<HWDB_MAX_PROPS){
                snprintf(cur->props[cur->nprops].key,64,"%s",s);
                snprintf(cur->props[cur->nprops].val,256,"%s",eq+1);
                cur->nprops++;
            }
            continue;
        }
        cur=NULL;
        if(line[0]=='#') continue;
        hwdb_add_entry(h,line);
        if(h->n) cur=&h->entries[h->n-1];
    }
    fclose(f);
}
static int cmp_names(const void *a, const void *b){
    return strcmp(*(const char * const *)a,*(const char * const *)b);
}
static void hwdb_load_dir(struct udev_hwdb *h, const char *dir){
    DIR *d=opendir(dir); if(!d) return;
    char *names[256]; int n=0; struct dirent *e;
    while((e=readdir(d)) && n<256){
        size_t L=strlen(e->d_name);
        if(L>5 && !strcmp(e->d_name+L-5,".hwdb")) names[n++]=strdup(e->d_name);
    }
    closedir(d);
    qsort(names,n,sizeof(char*),cmp_names);
    for(int i=0;i<n;i++){
        char p[1024]; snprintf(p,sizeof p,"%s/%s",dir,names[i]);
        hwdb_load_file(h,p);
        free(names[i]);
    }
}
static void hwdb_load_all(struct udev_hwdb *h){
    if(h->loaded) return;
    const char *path=getenv("UDEV_HWDB_PATH");
    if(path && path[0]){
        char buf[1024]; snprintf(buf,sizeof buf,"%s",path);
        char *save=NULL,*d=strtok_r(buf,":",&save);
        while(d){ if(*d) hwdb_load_dir(h,d); d=strtok_r(NULL,":",&save); }
    } else {
        hwdb_load_dir(h,"/etc/udev/hwdb.d");
        hwdb_load_dir(h,"/lib/udev/hwdb.d");
    }
    h->loaded=1;
}
static void list_append_unique(struct udev_list_entry **head, const char *name, const char *value){
    for(struct udev_list_entry *e=*head; e; e=e->next)
        if(!strcmp(e->name,name)) return;
    struct udev_list_entry *e=malloc(sizeof *e); if(!e) return;
    snprintf(e->name,sizeof e->name,"%s",name);
    snprintf(e->value,sizeof e->value,"%s",value?value:"");
    e->next=NULL;
    if(!*head){ *head=e; return; }
    struct udev_list_entry *t=*head; while(t->next) t=t->next; t->next=e;
}
struct udev_hwdb *udev_hwdb_new(struct udev *udev){
    struct udev_hwdb *h=calloc(1,sizeof *h); if(!h) return NULL;
    h->udev=udev_ref(udev); h->refcount=1;
    return h;
}
struct udev_hwdb *udev_hwdb_ref(struct udev_hwdb *h){ if(h) h->refcount++; return h; }
struct udev_hwdb *udev_hwdb_unref(struct udev_hwdb *h){
    if(!h) return NULL;
    if(--h->refcount>0) return NULL;
    free_list(&h->list);
    free(h->entries);
    udev_unref(h->udev);
    free(h);
    return NULL;
}
struct udev_list_entry *udev_hwdb_get_properties_list_entry(struct udev_hwdb *h, const char *modalias, unsigned flags){
    (void)flags;
    if(!h||!modalias) return NULL;
    hwdb_load_all(h);
    free_list(&h->list);
    for(int i=0;i<h->n;i++){
        if(fnmatch(h->entries[i].match,modalias,0)!=0) continue;
        for(int k=0;k<h->entries[i].nprops;k++)
            list_append_unique(&h->list,h->entries[i].props[k].key,h->entries[i].props[k].val);
    }
    if(!h->list){ errno=ENODATA; return NULL; }
    return h->list;
}

/* ===================== util ===================== */
static int utf8_valid_len(const char *s, size_t rem){
    const unsigned char *u=(const unsigned char*)s;
    if(u[0]<0x80) return 1;
    if(rem>=2 && (u[0]&0xE0)==0xC0 && (u[1]&0xC0)==0x80 && u[0]>=0xC2) return 2;
    if(rem>=3 && (u[0]&0xF0)==0xE0 && (u[1]&0xC0)==0x80 && (u[2]&0xC0)==0x80){
        if(u[0]==0xE0 && u[1]<0xA0) return 0;
        if(u[0]==0xED && u[1]>=0xA0) return 0;
        return 3;
    }
    if(rem>=4 && (u[0]&0xF8)==0xF0 && (u[1]&0xC0)==0x80 && (u[2]&0xC0)==0x80 && (u[3]&0xC0)==0x80){
        if(u[0]==0xF0 && u[1]<0x90) return 0;
        if(u[0]==0xF4 && u[1]>=0x90) return 0;
        if(u[0]>0xF4) return 0;
        return 4;
    }
    return 0;
}
int udev_util_encode_string(const char *str, char *str_enc, size_t len){
    if(!str||!str_enc||len==0) return -EINVAL;
    size_t i=0,j=0;
    for(; str[i]; i++){
        int sl=utf8_valid_len(str+i,strlen(str+i));
        if(sl>1){
            if(len-j<=(size_t)sl) goto trunc;
            memcpy(str_enc+j,str+i,(size_t)sl); j+=(size_t)sl; i+=sl-1;
        } else if(str[i]=='\\' || !((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='Z')
                   ||(str[i]>='a'&&str[i]<='z')||strchr("#+-.:=@_",str[i]))){
            if(len-j<5) goto trunc;
            snprintf(str_enc+j,5,"\\x%02x",(unsigned char)str[i]);
            j+=4;
        } else {
            if(len-j<2) goto trunc;
            str_enc[j++]=str[i];
        }
    }
    str_enc[j]=0;
    return 0;
trunc:
    str_enc[j]=0;
    return -EINVAL;
}
