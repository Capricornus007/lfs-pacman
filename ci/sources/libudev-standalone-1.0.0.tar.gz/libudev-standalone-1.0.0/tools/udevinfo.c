/*
 * udevinfo.c — minimal `udevadm info` clone.
 *
 * Links ONLY against libudev-standalone (never the daemon), demonstrating that
 * the library is a genuine drop-in: any program built against the real libudev
 * headers works unchanged. Point it at a fake root with UDEV_RUNDIR for testing.
 *
 *   UDEV_RUNDIR=/tmp/fakeroot udevinfo /dev/sda1
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <sys/sysmacros.h>
#include "udev.h"

int main(int argc, char **argv){
    const char *devpath=NULL;
    const char *devnum=NULL;
    int queue=0;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"--name")||!strcmp(argv[i],"-n")){ if(i+1<argc) devpath=argv[++i]; }
        else if(!strcmp(argv[i],"--path")){ if(i+1<argc) devpath=argv[++i]; }
        else if(!strcmp(argv[i],"--devnum")){ if(i+1<argc) devnum=argv[++i]; }
        else if(!strcmp(argv[i],"--queue")){ queue=1; }
        else if(argv[i][0]=='/'&&!devpath) devpath=argv[i];
    }
    if(!devpath && !devnum && !queue){
        fprintf(stderr,"usage: %s <device>   (e.g. /dev/sda1, a /sys path, --devnum b:8:1, or --queue)\n",argv[0]);
        return 1;
    }
    struct udev *udev=udev_new();
    if(!udev) return 1;
    if(queue){
        struct udev_queue *q=udev_queue_new(udev);
        printf("SEQNUM=%llu\n", (unsigned long long)udev_queue_get_udev_seqnum(q));
        printf("QUEUE_LENGTH=%d\n", udev_queue_get_queue_length(q));
        udev_queue_unref(q);
        udev_unref(udev);
        return 0;
    }
    struct udev_device *dev=NULL;
    if(devnum){
        char type='c'; unsigned mj=0,mn=0;
        if(sscanf(devnum,"%c:%u:%u",&type,&mj,&mn)==3)
            dev=udev_device_new_from_devnum(udev, type, makedev(mj,mn));
    } else if(!strncmp(devpath,"/sys/",5)) dev=udev_device_new_from_syspath(udev,devpath);
    else if(!strncmp(devpath,"/dev/",5)||devpath[0]!='/') dev=udev_device_new_from_devname(udev,devpath);
    else dev=udev_device_new_from_syspath(udev,devpath);
    if(!dev){ printf("no device for %s%s\n", devpath?devpath:"", devnum?devnum:""); udev_unref(udev); return 1; }

    printf("P: %s\n", udev_device_get_devpath(dev));
    const char *n=udev_device_get_devnode(dev); printf("N: %s\n", n?n:"");
    const char *s=udev_device_get_subsystem(dev); printf("E: SUBSYSTEM=%s\n", s?s:"");
    struct udev_list_entry *l;
    udev_list_entry_foreach(l, udev_device_get_properties_list_entry(dev))
        printf("E: %s=%s\n", udev_list_entry_get_name(l), udev_list_entry_get_value(l));

    udev_device_unref(dev);
    udev_unref(udev);
    return 0;
}
