#!/bin/sh
# End-to-end integration test: udev-standalone (daemon)  ->  libudev-standalone (client)
#
# Proves the real daemon can produce a device DB + queue and a genuine libudev
# client (built ONLY against libudev-standalone) can read it. No root and no live
# kernel netlink required: the daemon's `apply` subcommand processes a synthetic
# uevent and writes the real runtime state under UDEV_RUNDIR, which the client
# reads via the same env var.
#
# Usage:
#   UDEV_STANDALONE_BIN=/path/to/udev ./test/integration.sh
#   (defaults to ../udev-standalone/udev, i.e. the two repos are siblings)

set -u
here=$(cd "$(dirname "$0")" && pwd)
top=$(cd "$here/.." && pwd)

# locate the daemon binary
UDEV_BIN="${UDEV_STANDALONE_BIN:-../udev-standalone/udev}"
case "$UDEV_BIN" in
  /*) ;;                       # absolute, keep
  *)  UDEV_BIN="$top/$UDEV_BIN" ;;
esac
if [ ! -x "$UDEV_BIN" ]; then
  echo "FAIL: daemon binary not found: $UDEV_BIN" >&2
  echo "      set UDEV_STANDALONE_BIN to the built 'udev' executable." >&2
  exit 2
fi
UDEV_TESTDIR="$(cd "$(dirname "$UDEV_BIN")/test" && pwd)"
UDEV_INFO="$top/tools/udevinfo"

pass=0; fail=0
check() { # check <name> <expected-substring> <haystack>
  if printf '%s' "$3" | grep -qF -- "$2"; then
    echo "  PASS: $1 (found '$2')"; pass=$((pass+1))
  else
    echo "  FAIL: $1 (missing '$2')"; fail=$((fail+1))
  fi
}

echo "=== building libudev + udevinfo ==="
( cd "$top" && make >/dev/null 2>&1 ) || { echo "FAIL: libudev build"; exit 2; }

echo "=== Test A: daemon apply (input/mouse0) -> udevinfo by name ==="
R=$(mktemp -d)
export UDEV_RUNDIR="$R"
# use a DEVNAME that does NOT exist on the real system, so udevinfo's stat()
# fails and the libudev rundir-DB fallback reads our synthetic DB deterministically.
NODE="udevtest/mouse0"
sed "s|^DEVNAME=.*|DEVNAME=$NODE|" "$UDEV_TESTDIR/uevent-sample.txt" > "$R/uevent.txt"
out=$("$UDEV_BIN" apply "$R/uevent.txt" 2>&1)
info=$("$UDEV_INFO" "/dev/$NODE" 2>&1) || true
echo "$info"
check "A1 device DB written" "wrote $R/data/c13:32" "$out"
check "A2 devpath resolved"  "P: /devices"          "$info"
check "A3 devnode resolved"  "N: /dev/$NODE"        "$info"
check "A4 path_id builtin (ID_PATH)" "ID_PATH=pci-0000:00:14.0-usb-0:1:2:1.0" "$info"
check "A5 path_id builtin (ID_PATH_TAG)" "ID_PATH_TAG=pci_0000_00_14_0_usb_0_1_2_1_0" "$info"
rm -rf "$R"

echo "=== Test B: daemon apply (block + blkid) -> udevinfo by devnum ==="
R=$(mktemp -d)
export UDEV_RUNDIR="$R"
IMG=$(mktemp --suffix=.img)
sh "$UDEV_TESTDIR/mk-blkid-img.sh" "$IMG" >/dev/null
cat > "$R/uevent.txt" <<EOF
add@/devices/pci0000:00/0000:00:1f.2/ata1/host0/target0:0:0/0:0:0:0/block/sda/sda1
ACTION=add
DEVPATH=/devices/pci0000:00/0000:00:1f.2/ata1/host0/target0:0:0/0:0:0:0/block/sda/sda1
SUBSYSTEM=block
DEVNAME=$IMG
MAJOR=8
MINOR=1
EOF
out=$("$UDEV_BIN" apply "$R/uevent.txt" 2>&1)
info=$("$UDEV_INFO" --devnum b:8:1 2>&1) || true
echo "$info"
check "B1 device DB written" "wrote $R/data/b8:1" "$out"
check "B2 blkid FS type"     "ID_FS_TYPE=ext4"     "$info"
check "B3 blkid FS uuid"     "ID_FS_UUID="          "$info"
check "B4 blkid FS label"    "ID_FS_LABEL="         "$info"
rm -f "$IMG"; rm -rf "$R"

echo "=== Test C: daemon queue state -> libudev udev_queue_* (via --queue) ==="
R=$(mktemp -d)
export UDEV_RUNDIR="$R"
# two apply calls advance the udev seqnum; an add event nets QUEUE_LENGTH back to 0
"$UDEV_BIN" apply "$UDEV_TESTDIR/uevent-sample.txt" >/dev/null 2>&1
"$UDEV_BIN" apply "$UDEV_TESTDIR/uevent-sample.txt" >/dev/null 2>&1
q=$("$UDEV_INFO" --queue 2>&1) || true
echo "$q"
check "C1 udev seqnum advanced" "SEQNUM=2" "$q"
check "C2 queue drained (add nets to 0)" "QUEUE_LENGTH=0" "$q"
# apply mode also materialises a self-contained fake /dev tree under the rundir
check "C3 fake /dev node created" "dev/input/mouse0" "$(find "$R/dev" 2>/dev/null)"
# the daemon's own `udev queue` subcommand reads the same queue file
dq=$("$UDEV_BIN" queue 2>&1) || true
echo "$dq"
check "C4 daemon udev queue subcommand" "SEQNUM=2" "$dq"
rm -rf "$R"

echo "=== Test D: udev verify (rules syntax) ==="
RD="$(cd "$(dirname "$UDEV_BIN")/rules" && pwd)"
ok=$("$UDEV_BIN" verify "$RD" 2>&1); echo "$ok"
check "D1 valid rules pass" "OK" "$ok"
R=$(mktemp -d)
printf 'KERNEL=="sda" RUN+="/bin/echo hi\n' > "$R/bad.rules"
bad=$("$UDEV_BIN" verify "$R/bad.rules" 2>&1) || true
echo "$bad"
check "D2 malformed rule caught" "unbalanced quotes" "$bad"
rm -rf "$R"

echo "=== Test E: udev test (dry-run, sysfs + uevent file) ==="
t=$("$UDEV_BIN" test "$UDEV_TESTDIR/uevent-net.txt" 2>&1); echo "$t"
check "E1 uevent-file dry-run runs builtins" "ID_NET_NAME_PATH=enp0s3" "$t"
check "E2 uevent-file dry-run writes nothing" "dry-run, nothing written" "$t"
SP=$(for d in /sys/class/block/*; do if [ -e "$d/uevent" ]; then echo "$d"; break; fi; done)
if [ -n "${SP:-}" ]; then
  ts=$("$UDEV_BIN" test "$SP" 2>&1); echo "$ts"
  check "E3 sysfs device dry-run parses uevent" "test uevent:" "$ts"
  check "E4 sysfs dry-run writes nothing" "dry-run, nothing written" "$ts"
fi

echo "=== Test F: argv[0] personalities (udevadm / udev-hwdb) ==="
P=$(mktemp -d)
ln -s "$UDEV_BIN" "$P/udevadm"
ln -s "$UDEV_BIN" "$P/udev-hwdb"
a=$("$P/udevadm" verify "$RD" 2>&1); echo "$a" | tail -2
check "F1 udevadm personality dispatches" "OK" "$a"
h=$("$P/udev-hwdb" --hwdbdir="$(dirname "$UDEV_BIN")/examples/hwdb.d" query pci:v00008086d00001234sv00sd00bc00sc00i00 2>&1); echo "$h"
check "F2 udev-hwdb personality dispatches" "ID_VENDOR_FROM_DATABASE=Intel Corporation" "$h"
u=$("$P/udevadm" 2>&1); urc=$?; echo "$u"
check "F3 udevadm without command prints usage" "usage: udevadm" "$u"
if [ "$urc" -ne 0 ]; then
  echo "  PASS: F4 udevadm usage exits non-zero"; pass=$((pass+1))
else
  echo "  FAIL: F4 udevadm usage exits zero"; fail=$((fail+1))
fi
rm -rf "$P"

echo "=== Test G: udev test-builtin ==="
g1=$("$UDEV_BIN" test-builtin net_id "$UDEV_TESTDIR/uevent-net.txt" 2>&1); echo "$g1"
check "G1 net_id builtin output" "ID_NET_NAME_PATH=enp0s3" "$g1"
g2=$("$UDEV_BIN" test-builtin path_id "$UDEV_TESTDIR/uevent-usbpath.txt" 2>&1); echo "$g2"
check "G2 path_id builtin output" "ID_PATH=pci-0000:00:14.0-usb-0:1:2:1.0" "$g2"
g3=$("$UDEV_BIN" test-builtin nosuch "$UDEV_TESTDIR/uevent-net.txt" 2>&1); grc=$?; echo "$g3"
if [ "$grc" -ne 0 ]; then
  echo "  PASS: G3 unknown builtin exits non-zero"; pass=$((pass+1))
else
  echo "  FAIL: G3 unknown builtin exits zero"; fail=$((fail+1))
fi

echo "=== Test H: libudev self-test (full API surface) ==="
lt=$(cd "$top" && ./test/lutest 2>&1); echo "$lt" | tail -3
check "H1 lutest full API surface" "ALL OK" "$lt"

echo "=== Test I: drop-in dynamic link (client built against real system libudev) ==="
if [ -f /usr/include/libudev.h ]; then
  R=$(mktemp -d)
  cat > "$R/client.c" <<'EOF'
#include <libudev.h>
#include <stdio.h>
int main(void){
    struct udev *u=udev_new(); if(!u) return 1;
    struct udev_hwdb *h=udev_hwdb_new(u);
    printf("client ok hwdb=%s\n", h?"yes":"no");
    if(h) udev_hwdb_unref(h);
    udev_unref(u);
    return 0;
}
EOF
  if cc "$R/client.c" -o "$R/client" -ludev 2>/dev/null; then
    out=$(LD_LIBRARY_PATH="$top" "$R/client" 2>&1); echo "$out"
    check "I1 prebuilt client runs against libudev-standalone" "client ok" "$out"
  else
    echo "  SKIP: could not link against system libudev"
  fi
  rm -rf "$R"
else
  echo "  SKIP: /usr/include/libudev.h not installed"
fi

echo "=== Test J: versioned symbols (LIBUDEV_183 / LIBUDEV_247) ==="
vv=$(python3 - "$top/libudev.so.1" <<'PY'
import ctypes,sys
lib=ctypes.CDLL(sys.argv[1]); libc=ctypes.CDLL("libc.so.6")
libc.dlvsym.restype=ctypes.c_void_p
libc.dlvsym.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_char_p]
h=ctypes.cast(lib._handle,ctypes.c_void_p)
print("183" if libc.dlvsym(h,b"udev_new",b"LIBUDEV_183") else "missing")
print("247" if libc.dlvsym(h,b"udev_device_has_current_tag",b"LIBUDEV_247") else "missing")
PY
); echo "$vv"
check "J1 LIBUDEV_183 symbol resolves" "183" "$vv"
check "J2 LIBUDEV_247 symbol resolves" "247" "$vv"

echo "=== Test K: settle reads the daemon queue file ==="
R=$(mktemp -d)
printf 'SEQNUM=0\nQUEUE_LENGTH=0\n' > "$R/queue"
s0=$(UDEV_RUNDIR="$R" "$UDEV_BIN" settle 2>&1); echo "$s0"
check "K1 settle empty queue returns settled" "settled" "$s0"
printf 'SEQNUM=0\nQUEUE_LENGTH=2\n' > "$R/queue"
s2=$(UDEV_RUNDIR="$R" "$UDEV_BIN" settle --timeout 1 2>&1); krc=$?; echo "$s2"
check "K2 settle reports pending timeout" "timeout" "$s2"
if [ "$krc" -ne 0 ]; then
  echo "  PASS: K3 settle timeout exits non-zero"; pass=$((pass+1))
else
  echo "  FAIL: K3 settle timeout exits zero"; fail=$((fail+1))
fi
rm -rf "$R"

echo "=== Test L: udev info (udevadm-info-style) ==="
R=$(mktemp -d)
UDEV_RUNDIR="$R" "$UDEV_BIN" apply "$UDEV_TESTDIR/uevent-sample.txt" >/dev/null 2>&1
i1=$(UDEV_RUNDIR="$R" "$UDEV_BIN" info --db=c13:32 -q name 2>&1); echo "$i1"
check "L1 info -q name" "/dev/input/mouse0" "$i1"
i2=$(UDEV_RUNDIR="$R" "$UDEV_BIN" info --db=c13:32 -q property 2>&1); echo "$i2" | head -3
check "L2 info -q property" "SUBSYSTEM=input" "$i2"
i3=$(UDEV_RUNDIR="$R" "$UDEV_BIN" info --db=c13:32 2>&1); echo "$i3" | head -4
check "L3 info default shows P/N/S" "P: /devices" "$i3"
rm -rf "$R"

echo "=== Test M: action engine (PROGRAM/IMPORT/RUN/GOTO) ==="
m=$("$UDEV_BIN" --rules "$(dirname "$UDEV_BIN")/examples/rules" --test "$UDEV_TESTDIR/uevent-sample.txt" 2>&1)
echo "$m" | tail -8
check "M1 PROGRAM captures RESULT" "RESULT=captured-value" "$m"
check "M2 IMPORT loads variable" "IMPORTED_VAR=hello" "$m"
check "M3 RUN deferred to the event tail" "[would RUN] /bin/echo would-run" "$m"

echo "=== Test N: \$env{} expansion in SYMLINK (production rules) ==="
R=$(mktemp -d); IMG=$(mktemp --suffix=.img)
sh "$UDEV_TESTDIR/mk-blkid-img.sh" "$IMG" >/dev/null
sed -e "s|^DEVNAME=.*|DEVNAME=$IMG|" "$UDEV_TESTDIR/uevent-blkid.txt" > "$R/ue.txt"
printf 'MAJOR=8\nMINOR=1\n' >> "$R/ue.txt"
n=$("$UDEV_BIN" --rules "$(dirname "$UDEV_BIN")/rules" --test "$R/ue.txt" 2>&1)
echo "$n" | tail -8
check "N1 by-uuid symlink expanded" "symlink -> /dev/disk/by-uuid/" "$n"
check "N2 by-label symlink expanded" "symlink -> /dev/disk/by-label/" "$n"
rm -f "$IMG"; rm -rf "$R"

echo "=== Test O: version and trigger options ==="
o=$("$UDEV_BIN" --version 2>&1); echo "$o"
check "O1 version" "udev 1.0.0" "$o"
P=$(mktemp -d); ln -s "$UDEV_BIN" "$P/udevadm"
oa=$("$P/udevadm" --version 2>&1); echo "$oa"
check "O2 udevadm --version" "udev 1.0.0" "$oa"
tr=$("$P/udevadm" trigger --action=change --type=subsystems --test 2>&1); echo "$tr"
check "O3 trigger action/type parsed" "change" "$tr"
check "O4 subsystem trigger target" "/sys/bus" "$tr"
rm -rf "$P"

echo "=== Test P: bracket classes and static tty rules ==="
p=$("$UDEV_BIN" --rules "$(dirname "$UDEV_BIN")/rules" --test "$UDEV_TESTDIR/uevent-tty.txt" 2>&1); echo "$p"
check "P1 ttyS bracket class matches" "node=/dev/ttyS0 mode=660" "$p"
check "P2 ttyS group is dialout" "group=dialout" "$p"

echo
echo "=== summary: pass=$pass fail=$fail ==="
[ "$fail" -eq 0 ]
