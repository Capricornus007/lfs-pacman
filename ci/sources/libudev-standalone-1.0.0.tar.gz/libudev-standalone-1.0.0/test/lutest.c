/*
 * lutest.c — self-contained test of libudev-standalone.
 * Builds a fake /run/udev root in a temp dir, points the library at it via
 * UDEV_RUNDIR, then exercises the documented libudev API surface.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include "udev.h"

static int failures = 0;
#define CHECK(cond, name) do { \
    if (cond) printf("  PASS: %s\n", name); \
    else { printf("  FAIL: %s\n", name); failures++; } \
} while (0)

static void write_file(const char *path, const char *content){
    FILE *f=fopen(path,"w"); if(f){ fputs(content,f); fclose(f); }
}
static int count_list(struct udev_list_entry *e){
    int n=0; for(; e; e=udev_list_entry_get_next(e)) n++; return n;
}

int main(void){
    char root[256]; snprintf(root,sizeof root,"/tmp/udev-lutest.%d",(int)getpid());
    char data[300]; snprintf(data,sizeof data,"%s/data",root);
    mkdir(root,0755); mkdir(data,0755);

    struct timespec ts; clock_gettime(CLOCK_MONOTONIC,&ts);
    unsigned long long init_usec=(unsigned long long)ts.tv_sec*1000000ull + ts.tv_nsec/1000ull - 1000000ull;

    char db[400]; snprintf(db,sizeof db,"%s/data/b8:1",root);
    char dbcontent[2048];
    snprintf(dbcontent,sizeof dbcontent,
        "I:%llu\n"
        "E:SUBSYSTEM=block\n"
        "E:DEVTYPE=partition\n"
        "E:DEVPATH=/devices/pci0000:00/0000:00:1f.2/ata1/host0/target0:0:0/0:0:0:0/block/sda/sda1\n"
        "E:DEVNAME=sda1\n"
        "E:DEVLINKS=/dev/disk/by-id/test-disk /dev/disk/by-uuid/1234\n"
        "E:ID_FS_TYPE=ext4\n"
        "E:ID_FS_UUID=12345678-1234-1234-1234-123456789abc\n"
        "E:ID_MODEL=TestDisk\n"
        "E:TAGS=systemd,uaccess\n"
        "E:CURRENT_TAGS=:uaccess:\n", init_usec);
    write_file(db,dbcontent);

    char queue[300]; snprintf(queue,sizeof queue,"%s/queue",root);
    write_file(queue,"SEQNUM=42\nQUEUE_LENGTH=0\n");

    char hwdbdir[300]; snprintf(hwdbdir,sizeof hwdbdir,"%s/hwdb",root);
    mkdir(hwdbdir,0755);
    char hwdbf[400]; snprintf(hwdbf,sizeof hwdbf,"%s/50-test.hwdb",hwdbdir);
    write_file(hwdbf,
        "pci:v00008086d00001234*\n"
        " ID_VENDOR_FROM_DATABASE=Intel Corporation\n"
        " ID_MODEL_FROM_DATABASE=Example Host Bridge\n");

    setenv("UDEV_RUNDIR",root,1);
    setenv("UDEV_HWDB_PATH",hwdbdir,1);

    struct udev *udev = udev_new();
    if(!udev){ fprintf(stderr,"udev_new failed\n"); return 1; }

    printf("== context ==\n");
    CHECK(udev_get_dev_path(udev) && !strcmp(udev_get_dev_path(udev),"/dev"), "udev_get_dev_path");
    CHECK(udev_get_sys_path(udev) && udev_get_sys_path(udev)[0], "udev_get_sys_path");
    int marker=7; udev_set_userdata(udev,&marker);
    CHECK(udev_get_userdata(udev)==&marker, "udev_get/set_userdata");

    printf("== device from devnum 8:1 (block) ==\n");
    struct udev_device *dev = udev_device_new_from_devnum(udev,'b', makedev(8,1));
    CHECK(dev!=NULL, "udev_device_new_from_devnum");
    if(dev){
        CHECK(udev_device_get_udev(dev)==udev, "udev_device_get_udev");
        CHECK(udev_device_get_subsystem(dev) && !strcmp(udev_device_get_subsystem(dev),"block"), "subsystem=block");
        CHECK(udev_device_get_devtype(dev) && !strcmp(udev_device_get_devtype(dev),"partition"), "devtype=partition");
        CHECK(udev_device_get_devnode(dev) && !strcmp(udev_device_get_devnode(dev),"/dev/sda1"), "devnode=/dev/sda1");
        CHECK(udev_device_get_property_value(dev,"ID_FS_TYPE") && !strcmp(udev_device_get_property_value(dev,"ID_FS_TYPE"),"ext4"), "ID_FS_TYPE=ext4");
        CHECK(udev_device_has_tag(dev,"uaccess")==1, "has_tag uaccess");
        CHECK(udev_device_has_tag(dev,"nope")==0, "has_tag nope=0");
        CHECK(udev_device_has_current_tag(dev,"uaccess")==1, "has_current_tag uaccess");
        CHECK(udev_device_has_current_tag(dev,"nope")==0, "has_current_tag nope=0");
        CHECK(count_list(udev_device_get_current_tags_list_entry(dev))==1, "current tags list count=1");
        CHECK(count_list(udev_device_get_devlinks_list_entry(dev))==2, "devlinks list count=2");
        CHECK(udev_device_get_usec_since_initialized(dev)>=900000ull, "usec_since_initialized >= 0.9s");
        struct udev_list_entry *p;
        int props=0; udev_list_entry_foreach(p, udev_device_get_properties_list_entry(dev)) props++;
        CHECK(props>=8, "properties list populated");
        udev_device_unref(dev);
    }

    printf("== net device (nIFINDEX DB key) ==\n");
    char netdb[400]; snprintf(netdb,sizeof netdb,"%s/data/n1",root);
    char netcontent[512];
    snprintf(netcontent,sizeof netcontent,
        "I:%llu\n"
        "E:SUBSYSTEM=net\n"
        "E:DEVPATH=/devices/virtual/net/lo\n"
        "E:INTERFACE=lo\n"
        "E:IFINDEX=1\n"
        "E:ID_NET_NAME_PATH=fake-loopback\n", init_usec);
    write_file(netdb,netcontent);
    struct udev_device *net=udev_device_new_from_subsystem_sysname(udev,"net","lo");
    CHECK(net!=NULL, "new_from_subsystem_sysname(net,lo)");
    if(net){
        CHECK(udev_device_get_property_value(net,"ID_NET_NAME_PATH") &&
              !strcmp(udev_device_get_property_value(net,"ID_NET_NAME_PATH"),"fake-loopback"),
              "net DB read via n<ifindex>");
        udev_device_unref(net);
    }
    struct udev_device *net2=udev_device_new_from_device_id(udev,"n1");
    CHECK(net2 && udev_device_get_subsystem(net2) && !strcmp(udev_device_get_subsystem(net2),"net"),
          "new_from_device_id(n1)");

    printf("== non-devnum device (+subsys:sysname DB key) ==\n");
    char plusdb[400]; snprintf(plusdb,sizeof plusdb,"%s/data/+input:event99",root);
    write_file(plusdb,
        "E:SUBSYSTEM=input\n"
        "E:DEVPATH=/devices/virtual/input/input99/event99\n"
        "E:DEVNAME=input/event99\n");
    struct udev_device *plus=udev_device_new_from_device_id(udev,"+input:event99");
    CHECK(plus!=NULL, "new_from_device_id(+input:event99)");
    if(plus){
        CHECK(udev_device_get_property_value(plus,"DEVNAME") &&
              !strcmp(udev_device_get_property_value(plus,"DEVNAME"),"input/event99"),
              "non-devnum DB properties");
        CHECK(udev_device_get_syspath(plus) && strstr(udev_device_get_syspath(plus),"/devices/virtual/input/input99/event99"),
              "non-devnum syspath from DEVPATH");
        udev_device_unref(plus);
    }
    if(net2) udev_device_unref(net2);

    printf("== new_from_environment ==\n");
    setenv("DEVPATH","/devices/virtual/test0",1);
    setenv("SUBSYSTEM","block",1);
    struct udev_device *envdev=udev_device_new_from_environment(udev);
    CHECK(envdev!=NULL, "udev_device_new_from_environment");
    if(envdev){
        CHECK(udev_device_get_syspath(envdev) && strstr(udev_device_get_syspath(envdev),"/devices/virtual/test0"), "env DEVPATH -> syspath");
        CHECK(udev_device_get_property_value(envdev,"SUBSYSTEM") && !strcmp(udev_device_get_property_value(envdev,"SUBSYSTEM"),"block"), "env property copied");
        udev_device_unref(envdev);
    }

    printf("== enumerate ==\n");
    struct udev_enumerate *e = udev_enumerate_new(udev);
    CHECK(udev_enumerate_get_udev(e)==udev, "udev_enumerate_get_udev");
    udev_enumerate_add_match_subsystem(e,"block");
    udev_enumerate_scan_devices(e);
    CHECK(count_list(udev_enumerate_get_list_entry(e))>=1, "filtered scan finds block device");
    udev_enumerate_unref(e);

    struct udev_enumerate *ep = udev_enumerate_new(udev);
    udev_enumerate_add_syspath(ep,"/devices/virtual/test0");
    udev_enumerate_scan_devices(ep);
    int found_env=0, nlist=0;
    struct udev_list_entry *le;
    udev_list_entry_foreach(le, udev_enumerate_get_list_entry(ep)){
        nlist++;
        if(strstr(udev_list_entry_get_name(le),"/devices/virtual/test0")) found_env=1;
    }
    CHECK(found_env==1, "add_syspath included in scan");
    CHECK(nlist>=2, "scan_devices returns DB + explicit syspath");
    udev_enumerate_unref(ep);

    struct udev_enumerate *en = udev_enumerate_new(udev);
    udev_enumerate_add_match_subsystem(en,"net");
    udev_enumerate_scan_devices(en);
    int found_net=0;
    udev_list_entry_foreach(le, udev_enumerate_get_list_entry(en))
        if(strstr(udev_list_entry_get_name(le),"/net/lo")) found_net=1;
    CHECK(found_net==1, "net device enumerated from nIFINDEX DB");
    udev_enumerate_unref(en);

    printf("== scan_subsystems ==\n");
    struct udev_enumerate *es = udev_enumerate_new(udev);
    udev_enumerate_scan_subsystems(es);
    CHECK(count_list(udev_enumerate_get_list_entry(es))>0, "scan_subsystems non-empty");
    udev_enumerate_unref(es);

    printf("== hwdb ==\n");
    struct udev_hwdb *hw = udev_hwdb_new(udev);
    CHECK(hw!=NULL, "udev_hwdb_new");
    if(hw){
        struct udev_list_entry *hl=udev_hwdb_get_properties_list_entry(hw,"pci:v00008086d00001234sv00sd00bc00sc00i00",0);
        const char *v=udev_list_entry_get_by_name(hl,"ID_VENDOR_FROM_DATABASE") ?
            udev_list_entry_get_value(udev_list_entry_get_by_name(hl,"ID_VENDOR_FROM_DATABASE")) : NULL;
        CHECK(v && !strcmp(v,"Intel Corporation"), "hwdb vendor match");
        CHECK(udev_hwdb_get_properties_list_entry(hw,"usb:vFFFFFFFF*",0)==NULL, "hwdb miss returns NULL");
        udev_hwdb_unref(hw);
    }

    printf("== queue ==\n");
    struct udev_queue *q = udev_queue_new(udev);
    CHECK(udev_queue_get_udev(q)==udev, "udev_queue_get_udev");
    CHECK(udev_queue_get_udev_seqnum(q)==42, "udev seqnum=42");
    CHECK(udev_queue_get_queue_is_empty(q)==1, "get_queue_is_empty=1");
    CHECK(udev_queue_get_seqnum_is_finished(q,42)==1, "seqnum_is_finished=1");
    CHECK(udev_queue_get_seqnum_sequence_is_finished(q,1,42)==1, "seqnum_sequence_is_finished=1");
    CHECK(udev_queue_get_queued_list_entry(q)==NULL, "queued_list_entry=NULL");
    int qfd=udev_queue_get_fd(q);
    CHECK(qfd>=0, "queue_get_fd>=0");
    CHECK(qfd<0 || udev_queue_flush(q)==0, "queue_flush=0");
    udev_queue_unref(q);

    printf("== util ==\n");
    char enc[64];
    CHECK(udev_util_encode_string("a b/c",enc,sizeof enc)==0 && !strcmp(enc,"a\\x20b\\x2fc"), "encode unsafe chars");
    CHECK(udev_util_encode_string("valid-\xc3\xbc",enc,sizeof enc)==0 && !strcmp(enc,"valid-\xc3\xbc"), "encode keeps valid UTF-8");
    char small[3];
    CHECK(udev_util_encode_string("abc",small,sizeof small)!=0, "encode truncation fails");

    udev_unref(udev);

    unlink(db); unlink(netdb); unlink(plusdb); unlink(queue); unlink(hwdbf); rmdir(hwdbdir);
    rmdir(data); rmdir(root);
    if(failures){ printf("%d FAILURE(S)\n",failures); return 1; }
    printf("ALL OK\n");
    return 0;
}
